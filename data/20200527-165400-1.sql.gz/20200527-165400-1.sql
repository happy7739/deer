-- -----------------------------
-- MySQL Data Transfer
--
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : deer
--
-- Part : #1
-- Date : 2020-05-27 16:54:00
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `dp_admin_access`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_access`;
CREATE TABLE `dp_admin_access` (
  `module` varchar(16) NOT NULL DEFAULT '' COMMENT '模型名称',
  `group` varchar(16) NOT NULL DEFAULT '' COMMENT '权限分组标识',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `nid` varchar(16) NOT NULL DEFAULT '' COMMENT '授权节点id',
  `tag` varchar(16) NOT NULL DEFAULT '' COMMENT '分组标签'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='统一授权表';


-- -----------------------------
-- Table structure for `dp_admin_action`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_action`;
CREATE TABLE `dp_admin_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(16) NOT NULL DEFAULT '' COMMENT '所属模块名',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` varchar(80) NOT NULL DEFAULT '' COMMENT '行为标题',
  `remark` varchar(128) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=utf8 COMMENT='系统行为表';

-- -----------------------------
-- Records of `dp_admin_action`
-- -----------------------------
INSERT INTO `dp_admin_action` VALUES ('1', 'user', 'user_add', '添加用户', '添加用户', '', '[user|get_nickname] 添加了用户：[record|get_nickname]', '1', '1480156399', '1480163853');
INSERT INTO `dp_admin_action` VALUES ('2', 'user', 'user_edit', '编辑用户', '编辑用户', '', '[user|get_nickname] 编辑了用户：[details]', '1', '1480164578', '1480297748');
INSERT INTO `dp_admin_action` VALUES ('3', 'user', 'user_delete', '删除用户', '删除用户', '', '[user|get_nickname] 删除了用户：[details]', '1', '1480168582', '1480168616');
INSERT INTO `dp_admin_action` VALUES ('4', 'user', 'user_enable', '启用用户', '启用用户', '', '[user|get_nickname] 启用了用户：[details]', '1', '1480169185', '1480169185');
INSERT INTO `dp_admin_action` VALUES ('5', 'user', 'user_disable', '禁用用户', '禁用用户', '', '[user|get_nickname] 禁用了用户：[details]', '1', '1480169214', '1480170581');
INSERT INTO `dp_admin_action` VALUES ('6', 'user', 'user_access', '用户授权', '用户授权', '', '[user|get_nickname] 对用户：[record|get_nickname] 进行了授权操作。详情：[details]', '1', '1480221441', '1480221563');
INSERT INTO `dp_admin_action` VALUES ('7', 'user', 'role_add', '添加角色', '添加角色', '', '[user|get_nickname] 添加了角色：[details]', '1', '1480251473', '1480251473');
INSERT INTO `dp_admin_action` VALUES ('8', 'user', 'role_edit', '编辑角色', '编辑角色', '', '[user|get_nickname] 编辑了角色：[details]', '1', '1480252369', '1480252369');
INSERT INTO `dp_admin_action` VALUES ('9', 'user', 'role_delete', '删除角色', '删除角色', '', '[user|get_nickname] 删除了角色：[details]', '1', '1480252580', '1480252580');
INSERT INTO `dp_admin_action` VALUES ('10', 'user', 'role_enable', '启用角色', '启用角色', '', '[user|get_nickname] 启用了角色：[details]', '1', '1480252620', '1480252620');
INSERT INTO `dp_admin_action` VALUES ('11', 'user', 'role_disable', '禁用角色', '禁用角色', '', '[user|get_nickname] 禁用了角色：[details]', '1', '1480252651', '1480252651');
INSERT INTO `dp_admin_action` VALUES ('12', 'user', 'attachment_enable', '启用附件', '启用附件', '', '[user|get_nickname] 启用了附件：附件ID([details])', '1', '1480253226', '1480253332');
INSERT INTO `dp_admin_action` VALUES ('13', 'user', 'attachment_disable', '禁用附件', '禁用附件', '', '[user|get_nickname] 禁用了附件：附件ID([details])', '1', '1480253267', '1480253340');
INSERT INTO `dp_admin_action` VALUES ('14', 'user', 'attachment_delete', '删除附件', '删除附件', '', '[user|get_nickname] 删除了附件：附件ID([details])', '1', '1480253323', '1480253323');
INSERT INTO `dp_admin_action` VALUES ('15', 'admin', 'config_add', '添加配置', '添加配置', '', '[user|get_nickname] 添加了配置，[details]', '1', '1480296196', '1480296196');
INSERT INTO `dp_admin_action` VALUES ('16', 'admin', 'config_edit', '编辑配置', '编辑配置', '', '[user|get_nickname] 编辑了配置：[details]', '1', '1480296960', '1480296960');
INSERT INTO `dp_admin_action` VALUES ('17', 'admin', 'config_enable', '启用配置', '启用配置', '', '[user|get_nickname] 启用了配置：[details]', '1', '1480298479', '1480298479');
INSERT INTO `dp_admin_action` VALUES ('18', 'admin', 'config_disable', '禁用配置', '禁用配置', '', '[user|get_nickname] 禁用了配置：[details]', '1', '1480298506', '1480298506');
INSERT INTO `dp_admin_action` VALUES ('19', 'admin', 'config_delete', '删除配置', '删除配置', '', '[user|get_nickname] 删除了配置：[details]', '1', '1480298532', '1480298532');
INSERT INTO `dp_admin_action` VALUES ('20', 'admin', 'database_export', '备份数据库', '备份数据库', '', '[user|get_nickname] 备份了数据库：[details]', '1', '1480298946', '1480298946');
INSERT INTO `dp_admin_action` VALUES ('21', 'admin', 'database_import', '还原数据库', '还原数据库', '', '[user|get_nickname] 还原了数据库：[details]', '1', '1480301990', '1480302022');
INSERT INTO `dp_admin_action` VALUES ('22', 'admin', 'database_optimize', '优化数据表', '优化数据表', '', '[user|get_nickname] 优化了数据表：[details]', '1', '1480302616', '1480302616');
INSERT INTO `dp_admin_action` VALUES ('23', 'admin', 'database_repair', '修复数据表', '修复数据表', '', '[user|get_nickname] 修复了数据表：[details]', '1', '1480302798', '1480302798');
INSERT INTO `dp_admin_action` VALUES ('24', 'admin', 'database_backup_delete', '删除数据库备份', '删除数据库备份', '', '[user|get_nickname] 删除了数据库备份：[details]', '1', '1480302870', '1480302870');
INSERT INTO `dp_admin_action` VALUES ('25', 'admin', 'hook_add', '添加钩子', '添加钩子', '', '[user|get_nickname] 添加了钩子：[details]', '1', '1480303198', '1480303198');
INSERT INTO `dp_admin_action` VALUES ('26', 'admin', 'hook_edit', '编辑钩子', '编辑钩子', '', '[user|get_nickname] 编辑了钩子：[details]', '1', '1480303229', '1480303229');
INSERT INTO `dp_admin_action` VALUES ('27', 'admin', 'hook_delete', '删除钩子', '删除钩子', '', '[user|get_nickname] 删除了钩子：[details]', '1', '1480303264', '1480303264');
INSERT INTO `dp_admin_action` VALUES ('28', 'admin', 'hook_enable', '启用钩子', '启用钩子', '', '[user|get_nickname] 启用了钩子：[details]', '1', '1480303294', '1480303294');
INSERT INTO `dp_admin_action` VALUES ('29', 'admin', 'hook_disable', '禁用钩子', '禁用钩子', '', '[user|get_nickname] 禁用了钩子：[details]', '1', '1480303409', '1480303409');
INSERT INTO `dp_admin_action` VALUES ('30', 'admin', 'menu_add', '添加节点', '添加节点', '', '[user|get_nickname] 添加了节点：[details]', '1', '1480305468', '1480305468');
INSERT INTO `dp_admin_action` VALUES ('31', 'admin', 'menu_edit', '编辑节点', '编辑节点', '', '[user|get_nickname] 编辑了节点：[details]', '1', '1480305513', '1480305513');
INSERT INTO `dp_admin_action` VALUES ('32', 'admin', 'menu_delete', '删除节点', '删除节点', '', '[user|get_nickname] 删除了节点：[details]', '1', '1480305562', '1480305562');
INSERT INTO `dp_admin_action` VALUES ('33', 'admin', 'menu_enable', '启用节点', '启用节点', '', '[user|get_nickname] 启用了节点：[details]', '1', '1480305630', '1480305630');
INSERT INTO `dp_admin_action` VALUES ('34', 'admin', 'menu_disable', '禁用节点', '禁用节点', '', '[user|get_nickname] 禁用了节点：[details]', '1', '1480305659', '1480305659');
INSERT INTO `dp_admin_action` VALUES ('35', 'admin', 'module_install', '安装模块', '安装模块', '', '[user|get_nickname] 安装了模块：[details]', '1', '1480307558', '1480307558');
INSERT INTO `dp_admin_action` VALUES ('36', 'admin', 'module_uninstall', '卸载模块', '卸载模块', '', '[user|get_nickname] 卸载了模块：[details]', '1', '1480307588', '1480307588');
INSERT INTO `dp_admin_action` VALUES ('37', 'admin', 'module_enable', '启用模块', '启用模块', '', '[user|get_nickname] 启用了模块：[details]', '1', '1480307618', '1480307618');
INSERT INTO `dp_admin_action` VALUES ('38', 'admin', 'module_disable', '禁用模块', '禁用模块', '', '[user|get_nickname] 禁用了模块：[details]', '1', '1480307653', '1480307653');
INSERT INTO `dp_admin_action` VALUES ('39', 'admin', 'module_export', '导出模块', '导出模块', '', '[user|get_nickname] 导出了模块：[details]', '1', '1480307682', '1480307682');
INSERT INTO `dp_admin_action` VALUES ('40', 'admin', 'packet_install', '安装数据包', '安装数据包', '', '[user|get_nickname] 安装了数据包：[details]', '1', '1480308342', '1480308342');
INSERT INTO `dp_admin_action` VALUES ('41', 'admin', 'packet_uninstall', '卸载数据包', '卸载数据包', '', '[user|get_nickname] 卸载了数据包：[details]', '1', '1480308372', '1480308372');
INSERT INTO `dp_admin_action` VALUES ('42', 'admin', 'system_config_update', '更新系统设置', '更新系统设置', '', '[user|get_nickname] 更新了系统设置：[details]', '1', '1480309555', '1480309642');
INSERT INTO `dp_admin_action` VALUES ('43', 'cms', 'slider_delete', '删除滚动图片', '删除滚动图片', '', '[user|get_nickname] 删除了滚动图片：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('44', 'cms', 'slider_edit', '编辑滚动图片', '编辑滚动图片', '', '[user|get_nickname] 编辑了滚动图片：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('45', 'cms', 'slider_add', '添加滚动图片', '添加滚动图片', '', '[user|get_nickname] 添加了滚动图片：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('46', 'cms', 'document_delete', '删除文档', '删除文档', '', '[user|get_nickname] 删除了文档：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('47', 'cms', 'document_restore', '还原文档', '还原文档', '', '[user|get_nickname] 还原了文档：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('48', 'cms', 'nav_disable', '禁用导航', '禁用导航', '', '[user|get_nickname] 禁用了导航：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('49', 'cms', 'nav_enable', '启用导航', '启用导航', '', '[user|get_nickname] 启用了导航：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('50', 'cms', 'nav_delete', '删除导航', '删除导航', '', '[user|get_nickname] 删除了导航：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('51', 'cms', 'nav_edit', '编辑导航', '编辑导航', '', '[user|get_nickname] 编辑了导航：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('52', 'cms', 'nav_add', '添加导航', '添加导航', '', '[user|get_nickname] 添加了导航：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('53', 'cms', 'model_disable', '禁用内容模型', '禁用内容模型', '', '[user|get_nickname] 禁用了内容模型：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('54', 'cms', 'model_enable', '启用内容模型', '启用内容模型', '', '[user|get_nickname] 启用了内容模型：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('55', 'cms', 'model_delete', '删除内容模型', '删除内容模型', '', '[user|get_nickname] 删除了内容模型：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('56', 'cms', 'model_edit', '编辑内容模型', '编辑内容模型', '', '[user|get_nickname] 编辑了内容模型：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('57', 'cms', 'model_add', '添加内容模型', '添加内容模型', '', '[user|get_nickname] 添加了内容模型：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('58', 'cms', 'menu_disable', '禁用导航菜单', '禁用导航菜单', '', '[user|get_nickname] 禁用了导航菜单：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('59', 'cms', 'menu_enable', '启用导航菜单', '启用导航菜单', '', '[user|get_nickname] 启用了导航菜单：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('60', 'cms', 'menu_delete', '删除导航菜单', '删除导航菜单', '', '[user|get_nickname] 删除了导航菜单：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('61', 'cms', 'menu_edit', '编辑导航菜单', '编辑导航菜单', '', '[user|get_nickname] 编辑了导航菜单：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('62', 'cms', 'menu_add', '添加导航菜单', '添加导航菜单', '', '[user|get_nickname] 添加了导航菜单：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('63', 'cms', 'link_disable', '禁用友情链接', '禁用友情链接', '', '[user|get_nickname] 禁用了友情链接：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('64', 'cms', 'link_enable', '启用友情链接', '启用友情链接', '', '[user|get_nickname] 启用了友情链接：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('65', 'cms', 'link_delete', '删除友情链接', '删除友情链接', '', '[user|get_nickname] 删除了友情链接：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('66', 'cms', 'link_edit', '编辑友情链接', '编辑友情链接', '', '[user|get_nickname] 编辑了友情链接：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('67', 'cms', 'link_add', '添加友情链接', '添加友情链接', '', '[user|get_nickname] 添加了友情链接：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('68', 'cms', 'field_disable', '禁用模型字段', '禁用模型字段', '', '[user|get_nickname] 禁用了模型字段：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('69', 'cms', 'field_enable', '启用模型字段', '启用模型字段', '', '[user|get_nickname] 启用了模型字段：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('70', 'cms', 'field_delete', '删除模型字段', '删除模型字段', '', '[user|get_nickname] 删除了模型字段：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('71', 'cms', 'field_edit', '编辑模型字段', '编辑模型字段', '', '[user|get_nickname] 编辑了模型字段：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('72', 'cms', 'field_add', '添加模型字段', '添加模型字段', '', '[user|get_nickname] 添加了模型字段：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('73', 'cms', 'column_disable', '禁用栏目', '禁用栏目', '', '[user|get_nickname] 禁用了栏目：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('74', 'cms', 'column_enable', '启用栏目', '启用栏目', '', '[user|get_nickname] 启用了栏目：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('75', 'cms', 'column_delete', '删除栏目', '删除栏目', '', '[user|get_nickname] 删除了栏目：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('76', 'cms', 'column_edit', '编辑栏目', '编辑栏目', '', '[user|get_nickname] 编辑了栏目：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('77', 'cms', 'column_add', '添加栏目', '添加栏目', '', '[user|get_nickname] 添加了栏目：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('78', 'cms', 'advert_type_disable', '禁用广告分类', '禁用广告分类', '', '[user|get_nickname] 禁用了广告分类：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('79', 'cms', 'advert_type_enable', '启用广告分类', '启用广告分类', '', '[user|get_nickname] 启用了广告分类：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('80', 'cms', 'advert_type_delete', '删除广告分类', '删除广告分类', '', '[user|get_nickname] 删除了广告分类：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('81', 'cms', 'advert_type_edit', '编辑广告分类', '编辑广告分类', '', '[user|get_nickname] 编辑了广告分类：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('82', 'cms', 'advert_type_add', '添加广告分类', '添加广告分类', '', '[user|get_nickname] 添加了广告分类：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('83', 'cms', 'advert_disable', '禁用广告', '禁用广告', '', '[user|get_nickname] 禁用了广告：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('84', 'cms', 'advert_enable', '启用广告', '启用广告', '', '[user|get_nickname] 启用了广告：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('85', 'cms', 'advert_delete', '删除广告', '删除广告', '', '[user|get_nickname] 删除了广告：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('86', 'cms', 'advert_edit', '编辑广告', '编辑广告', '', '[user|get_nickname] 编辑了广告：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('87', 'cms', 'advert_add', '添加广告', '添加广告', '', '[user|get_nickname] 添加了广告：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('88', 'cms', 'document_disable', '禁用文档', '禁用文档', '', '[user|get_nickname] 禁用了文档：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('89', 'cms', 'document_enable', '启用文档', '启用文档', '', '[user|get_nickname] 启用了文档：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('90', 'cms', 'document_trash', '回收文档', '回收文档', '', '[user|get_nickname] 回收了文档：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('91', 'cms', 'document_edit', '编辑文档', '编辑文档', '', '[user|get_nickname] 编辑了文档：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('92', 'cms', 'document_add', '添加文档', '添加文档', '', '[user|get_nickname] 添加了文档：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('93', 'cms', 'slider_enable', '启用滚动图片', '启用滚动图片', '', '[user|get_nickname] 启用了滚动图片：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('94', 'cms', 'slider_disable', '禁用滚动图片', '禁用滚动图片', '', '[user|get_nickname] 禁用了滚动图片：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('95', 'cms', 'support_add', '添加客服', '添加客服', '', '[user|get_nickname] 添加了客服：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('96', 'cms', 'support_edit', '编辑客服', '编辑客服', '', '[user|get_nickname] 编辑了客服：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('97', 'cms', 'support_delete', '删除客服', '删除客服', '', '[user|get_nickname] 删除了客服：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('98', 'cms', 'support_enable', '启用客服', '启用客服', '', '[user|get_nickname] 启用了客服：[details]', '1', '1590459540', '1590459540');
INSERT INTO `dp_admin_action` VALUES ('99', 'cms', 'support_disable', '禁用客服', '禁用客服', '', '[user|get_nickname] 禁用了客服：[details]', '1', '1590459540', '1590459540');

-- -----------------------------
-- Table structure for `dp_admin_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_attachment`;
CREATE TABLE `dp_admin_attachment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '文件名',
  `module` varchar(32) NOT NULL DEFAULT '' COMMENT '模块名，由哪个模块上传的',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '文件路径',
  `thumb` varchar(255) NOT NULL DEFAULT '' COMMENT '缩略图路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '文件链接',
  `mime` varchar(128) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `ext` char(8) NOT NULL DEFAULT '' COMMENT '文件类型',
  `size` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT 'sha1 散列值',
  `driver` varchar(16) NOT NULL DEFAULT 'local' COMMENT '上传驱动',
  `download` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `width` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '图片宽度',
  `height` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '图片高度',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=90 DEFAULT CHARSET=utf8 COMMENT='附件表';

-- -----------------------------
-- Records of `dp_admin_attachment`
-- -----------------------------
INSERT INTO `dp_admin_attachment` VALUES ('14', '1', 'da1.jpg', 'admin', 'uploads/images/20200526/dfed44c9a9a110b6a408f499026a06aa.jpg', '', '', 'image/jpeg', 'jpg', '87033', 'a98bc0fee3e118e0412b5cc6020936d1', '3ba5e8c24ea55189a60ccfdd080e4b56cac51caf', 'local', '0', '1590475666', '1590475666', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('15', '1', 'da2.jpg', 'admin', 'uploads/images/20200526/c4377a2e4a3115253df5dc05f79a0e00.jpg', '', '', 'image/jpeg', 'jpg', '84490', '4ef267ba53405403c08a0414e7ef6af0', '7529ed1919514ed52e0c7365052b9f8b8cb8b613', 'local', '0', '1590475837', '1590475837', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('5', '1', '1425192535736.jpg', 'admin', 'uploads/images/20200526/d24bda4c13c8c0b5aa0f712fcd53d4cb.jpg', '', '', 'image/jpeg', 'jpg', '225628', 'edde9113834ddcd2a469dc9bb8058d5b', 'df9c3684413f8914c46e4b0ca592fa68455f87c7', 'local', '0', '1590458693', '1590458693', '100', '1', '900', '1153');
INSERT INTO `dp_admin_attachment` VALUES ('8', '1', 'logo.png', 'admin', 'uploads/images/20200526/6f1b133024d09018a38c5f98f0b3815c.png', '', '', 'image/png', 'png', '1373809', 'e0f0920dec6129794d803288d26c13a6', 'd7d24e4f482f74194bfcb7744f52273e6c1beac7', 'local', '0', '1590463224', '1590463224', '100', '1', '4323', '4099');
INSERT INTO `dp_admin_attachment` VALUES ('16', '1', 'da3.jpg', 'admin', 'uploads/images/20200526/79f0acc5828cc243a33dde83c54b543a.jpg', '', '', 'image/jpeg', 'jpg', '90296', '93ef67c6dfad75e73c26be2a24f29a3d', 'ee82a064c879cc59da8d0abd0c43a6eb825a092e', 'local', '0', '1590475860', '1590475860', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('17', '1', 'da4.jpg', 'admin', 'uploads/images/20200526/bc5389350c63c8bbb32bfd4db7eae241.jpg', '', '', 'image/jpeg', 'jpg', '85066', '02e0313d1b6a034c26c8d6fe094dd913', '9e1f962388f4e351e3dbb21021a5cc905ff2fb4e', 'local', '0', '1590475889', '1590475889', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('18', '1', 'da5.jpg', 'admin', 'uploads/images/20200526/7c71d486b21e8b1542eff7c5c3ec403f.jpg', '', '', 'image/jpeg', 'jpg', '64175', 'b0df16871cf0f1e95718f77391c2112f', '7c7a11333a4e91eca6aff10a5a7f068bc1fb29e1', 'local', '0', '1590475914', '1590475914', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('19', '1', 'da6.jpg', 'admin', 'uploads/images/20200526/c08eda2f4d2b1ed8a1ca525ffbc63336.jpg', '', '', 'image/jpeg', 'jpg', '103934', 'd5635e40451a2280a57091e2b385f872', 'aad2042787ee6d9b98ac0b2a7434b9ac501dcdc9', 'local', '0', '1590475934', '1590475934', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('20', '1', '1.jpg', 'admin', 'uploads/images/20200526/0ef5f3026471b49559a5b1afe4a77ab6.jpg', '', '', 'image/jpeg', 'jpg', '60078', 'f6ffb13ae37bfa3e425e22da49b1384b', '69a3adf0f6c2603013e13abe7ebffa9911fd5744', 'local', '0', '1590476020', '1590476020', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('21', '1', '2.jpg', 'admin', 'uploads/images/20200526/a3c62aec72960be9ecd544b7bbe58daf.jpg', '', '', 'image/jpeg', 'jpg', '56323', 'a74563303c38e38d1aa742971faca49a', '9211a9cbc4f9bfa927553b5d0f73c19a4389f7f1', 'local', '0', '1590476039', '1590476039', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('22', '1', '3.jpg', 'admin', 'uploads/images/20200526/9809a453efe105180bf60f320139f93c.jpg', '', '', 'image/jpeg', 'jpg', '49601', 'a78884cc0e20fa87015196f0732a9e91', '816432ffd146d87ddadd8efde76f98a1562d7c8e', 'local', '0', '1590476075', '1590476075', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('23', '1', '4.jpg', 'admin', 'uploads/images/20200526/de46cb83dec94560ed356fa91ebab10e.jpg', '', '', 'image/jpeg', 'jpg', '64041', '2bc1d06ee335b5a31fa369ac9f2d3bc2', '03e77286d214086f503cf23ee883fae9d71c2318', 'local', '0', '1590476093', '1590476093', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('24', '1', '5.jpg', 'admin', 'uploads/images/20200526/6ff6909bbce9b0d6fe150f399b0892a5.jpg', '', '', 'image/jpeg', 'jpg', '34869', '3c49330aa3986a8ec4d34df6f465c312', 'e54c3d4bbc62e1bd7e5d2d3a3e508ecc8ecd200b', 'local', '0', '1590476112', '1590476112', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('28', '1', '8.jpg', 'admin', 'uploads/images/20200526/baed37022786702e051eb16fda922e4c.jpg', '', '', 'image/jpeg', 'jpg', '48700', 'aebbd6724c85288a045144c7f397da48', '6691f430861edbf993bd97376db9aa32cc6216cb', 'local', '0', '1590476614', '1590476614', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('27', '1', '6.jpg', 'admin', 'uploads/images/20200526/f63988450d4acfa9554919df6512124c.jpg', '', '', 'image/jpeg', 'jpg', '24133', '492917dbe6ba0ede44e6735ce832cacb', '0b9a6199e74f60c193394741fc3b56fc19eaed02', 'local', '0', '1590476586', '1590476586', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('29', '1', '9.jpg', 'admin', 'uploads/images/20200526/f4fdc6fb02a82c7af2c452580cf6812f.jpg', '', '', 'image/jpeg', 'jpg', '59097', 'b44342b72ce4d82bd459427c9d0dcfc3', '0c4803ca5cacb4b0d075c5cf2fedb41d29838457', 'local', '0', '1590476632', '1590476632', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('30', '1', '10.jpg', 'admin', 'uploads/images/20200526/724c84c74bbb4255cdadf3df4dfe6057.jpg', '', '', 'image/jpeg', 'jpg', '53699', 'c4c2ab133dba151b952e45cbe1749df7', '9c7f45e425966595a04bfb79c42d98d0fb3d1a42', 'local', '0', '1590476659', '1590476659', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('31', '1', '11.jpg', 'admin', 'uploads/images/20200526/f603f7e04d150fc7517e9f5c1ab1fcbc.jpg', '', '', 'image/jpeg', 'jpg', '59173', '07ff88017b54bf2a2fe0f7c64fefae64', '29bc7daea43a27359d24b87b56fef6676547fabf', 'local', '0', '1590476721', '1590476721', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('32', '1', '12.jpg', 'admin', 'uploads/images/20200526/23eb4a3d36950f50ae5a999cdb31a305.jpg', '', '', 'image/jpeg', 'jpg', '41126', 'e25aac258d298feccf7431a8038b2553', '644cdc5f532e11af25feb67bfd2b5f3b1e5a83b0', 'local', '0', '1590476742', '1590476742', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('33', '1', '13.jpg', 'admin', 'uploads/images/20200526/b14c62ca3c048ea31653c586428b7918.jpg', '', '', 'image/jpeg', 'jpg', '52420', '5366b8b0abbbbe173c212f27d35b26b1', '7d467ec9af5eec61fbbc2e5afafd311cfb9060ca', 'local', '0', '1590476763', '1590476763', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('34', '1', '14.jpg', 'admin', 'uploads/images/20200526/8464e20d94ae86605babaed417fb2124.jpg', '', '', 'image/jpeg', 'jpg', '37387', '1e2753482eb29e024b47c43ca64d6e7d', 'cb6930503e31e2f4ccd58befa5acbe61b4f3261d', 'local', '0', '1590476783', '1590476783', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('35', '1', '15.jpg', 'admin', 'uploads/images/20200526/53045e083df605e5e9f47599c36adc6d.jpg', '', '', 'image/jpeg', 'jpg', '46344', 'f0f7c8e06735abd4acfee57e8e14c1bd', '15340976f3c23c43baaf074062f3c2b6562c9a14', 'local', '0', '1590476801', '1590476801', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('36', '1', '16.jpg', 'admin', 'uploads/images/20200526/0af3dd1d56a1b56db1a9474e072b4e2f.jpg', '', '', 'image/jpeg', 'jpg', '43120', '51e7c0329508616bc8638744198ffd5b', '3464bffd2913ec6ea9f83b508098db7d23cae147', 'local', '0', '1590476820', '1590476820', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('37', '1', '17.jpg', 'admin', 'uploads/images/20200526/4a9632efa952a09ae882aeffb1bba785.jpg', '', '', 'image/jpeg', 'jpg', '50617', 'deb1ed52cde6ee93cf252a36265957ba', '801eac866fa0820023cc24b38af2b6d524fdb659', 'local', '0', '1590476833', '1590476833', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('38', '1', '18.jpg', 'admin', 'uploads/images/20200526/d1e49f1d923f33ca357cbcd645aed49d.jpg', '', '', 'image/jpeg', 'jpg', '45439', 'fcbc96f35c5e65d7bd1a07e4dc556d39', '80d7102aa4d1240caf9c848188060932238604b9', 'local', '0', '1590476853', '1590476853', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('39', '1', '19.jpg', 'admin', 'uploads/images/20200526/becd3b15635c3f0402a1a76b52517ab0.jpg', '', '', 'image/jpeg', 'jpg', '28984', '82281418a3fba2df6ebdc44969fda615', '22b99f997e3dc8250b8c62b8660e36883d99bacf', 'local', '0', '1590476865', '1590476865', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('40', '1', '20.jpg', 'admin', 'uploads/images/20200526/03c79a53282c330e3c04750a586f312e.jpg', '', '', 'image/jpeg', 'jpg', '45499', '2209169c63da54fe663ce213288a53bd', '3c90812f8af1a5d9d40ab0988dab6ea9ca77c4d2', 'local', '0', '1590476895', '1590476895', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('41', '1', '21.jpg', 'admin', 'uploads/images/20200526/20558a76d96e2574293c7400d3a1baa9.jpg', '', '', 'image/jpeg', 'jpg', '43043', '1c18e1a6c5311a3c40fa9ee9cac989cf', '533eaa8eff5b10e37b291bac8eeeb64dfcfdf2cd', 'local', '0', '1590476915', '1590476915', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('42', '1', '22.jpg', 'admin', 'uploads/images/20200526/452ecc434207520db984a7f59567cf07.jpg', '', '', 'image/jpeg', 'jpg', '40826', '5983d5efadbcd7d81f63948d6bc3c357', 'b28d4f52fbe345c3d0e6a63f28e86a7d5d2f92b4', 'local', '0', '1590476933', '1590476933', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('43', '1', '23.jpg', 'admin', 'uploads/images/20200526/f0a7da6ad638479546270df2fdd9b711.jpg', '', '', 'image/jpeg', 'jpg', '49893', 'f56498ef18e1ed8fb6bc5524465e78ba', '9b394034c01426ee548bbab9ace3bdf7838a4279', 'local', '0', '1590476951', '1590476951', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('44', '1', '24.jpg', 'admin', 'uploads/images/20200526/0c468da77c598504a4eaf5b2d30061b2.jpg', '', '', 'image/jpeg', 'jpg', '38295', '40a6d4c2facf18c851799504615229f1', 'b501953e5b8c89e55ef917986ae1ddb9b57fd2cd', 'local', '0', '1590476972', '1590476972', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('45', '1', '25.jpg', 'admin', 'uploads/images/20200526/f983862aaa5d9c7e72ef0f4cb3c7ec81.jpg', '', '', 'image/jpeg', 'jpg', '51464', '27832a0474d52291be5b589107c00613', '714110d437d3eea766ac372458140799921c7e4e', 'local', '0', '1590476989', '1590476989', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('46', '1', '26.jpg', 'admin', 'uploads/images/20200526/33d6026385e44b1d8080ec65c4c25d29.jpg', '', '', 'image/jpeg', 'jpg', '34799', '71c8912bb62191c92331bf9b040c978c', 'edde78a27aac01d0b86509174dabc34ea7a7e0f6', 'local', '0', '1590477115', '1590477115', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('47', '1', '27.jpg', 'admin', 'uploads/images/20200526/78d6b0cbe902fcfbe10c963535329db5.jpg', '', '', 'image/jpeg', 'jpg', '39055', 'fe5be95903ddf589cbf9ba1ba12652ac', '9ab0852fa933e7931a59fefe3fc7b55734508636', 'local', '0', '1590477134', '1590477134', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('48', '1', '28.jpg', 'admin', 'uploads/images/20200526/7faced06440ced4e680560b7947c0a22.jpg', '', '', 'image/jpeg', 'jpg', '42398', '5bee1f417c7877768b6daa04f24a53d2', '45e822ec0b59dc5f4a9705b9998cac5b2df5c869', 'local', '0', '1590477150', '1590477150', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('49', '1', '29.jpg', 'admin', 'uploads/images/20200526/f7daa033d88f723b4aed31eedfa2a2b7.jpg', '', '', 'image/jpeg', 'jpg', '37644', 'd154915ec99138af0277d2233b35470d', '8f1237b637590d88f6e25bfc6f2f6369447502f3', 'local', '0', '1590477486', '1590477486', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('50', '1', '30.jpg', 'admin', 'uploads/images/20200526/0301f33db726d193f69f2271e035eecf.jpg', '', '', 'image/jpeg', 'jpg', '60026', '27afd0df72de01b87681463e1f61884b', '04a15adc053e129af9089776a174059ced097606', 'local', '0', '1590477511', '1590477511', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('51', '1', '31.jpg', 'admin', 'uploads/images/20200526/7f212e018655d417c682ce93f415ff31.jpg', '', '', 'image/jpeg', 'jpg', '48182', '9b984cc52a54de871e13403a6bbead3e', '58bf2c1ef248ab969953b4a518cd9f2391a7847e', 'local', '0', '1590477538', '1590477538', '100', '1', '470', '270');
INSERT INTO `dp_admin_attachment` VALUES ('52', '1', 'gj2.png', '', 'uploads/images/20200526/56a87c17cc72c4a975cea71fcc2a0b27.png', '', '', 'image/png', 'png', '662636', 'e960d041ffc0d60437f3b82a4e3be3f1', 'b83211e1dcbfd8cefe1c56c1d8f462f1310bd12b', 'local', '0', '1590480016', '1590480016', '100', '1', '960', '720');
INSERT INTO `dp_admin_attachment` VALUES ('53', '1', 'gj1.png', '', 'uploads/images/20200526/79d1db047a5048b6902386c54336d8c1.png', '', '', 'image/png', 'png', '663376', 'f7a3d2bff5040a79bbfb539139c7b6b8', '56252c172a9e6d4d5a02ea70755f32c1fb11ebc3', 'local', '0', '1590480016', '1590480016', '100', '1', '960', '720');
INSERT INTO `dp_admin_attachment` VALUES ('54', '1', 'md1.png', '', 'uploads/images/20200526/971473e0c0a203ddcfea2dde409b864f.png', '', '', 'image/png', 'png', '1332111', 'ed850e990e6a8968c2c60d6cd933b01d', 'eed9c8fa1c1f14606f86b69f940bfd820664c7da', 'local', '0', '1590482603', '1590482603', '100', '1', '960', '720');
INSERT INTO `dp_admin_attachment` VALUES ('55', '1', 'md4.png', '', 'uploads/images/20200526/8c47849f95764b3e0635595cb3479a23.png', '', '', 'image/png', 'png', '1140314', 'b53fdfd6dd77f275ab2afc7345055f69', '61d647f8c06fe54915a640d1d7bfbdc62d48edc2', 'local', '0', '1590482603', '1590482603', '100', '1', '960', '720');
INSERT INTO `dp_admin_attachment` VALUES ('56', '1', 'md5.png', '', 'uploads/images/20200526/3ee0bdc2fad9cb7c5025e6266b064036.png', '', '', 'image/png', 'png', '1095694', 'f6489f5d297b5b210fc26714229ace32', '69f59fcd4042ba60c4d142bf5f479b9079bc330e', 'local', '0', '1590482603', '1590482603', '100', '1', '960', '720');
INSERT INTO `dp_admin_attachment` VALUES ('57', '1', 'md3.png', '', 'uploads/images/20200526/202d9caaf0f3b65a856fd9484f4fe3aa.png', '', '', 'image/png', 'png', '1270583', '164cca96719063c2b21a074601107f06', 'cd8719c00f142cae34eb50d4e41bdee265d40c0b', 'local', '0', '1590482604', '1590482604', '100', '1', '960', '720');
INSERT INTO `dp_admin_attachment` VALUES ('58', '1', 'md6.png', '', 'uploads/images/20200526/77467b7ade031b984588925e84b216d5.png', '', '', 'image/png', 'png', '1211188', 'c8256cbab193c5ac7042aaba087ca8cf', '4d63dbc2e1a798f4de7b221675dce16149bec533', 'local', '0', '1590482604', '1590482604', '100', '1', '960', '720');
INSERT INTO `dp_admin_attachment` VALUES ('59', '1', 'md7.png', '', 'uploads/images/20200526/7bd0562808d3d6874672b8757a693a13.png', '', '', 'image/png', 'png', '1179871', 'f43812a62c57c74e5e67350bd7d4b850', 'bcdde562ed5efe94ac5020519443b0ea8238171d', 'local', '0', '1590482604', '1590482604', '100', '1', '960', '720');
INSERT INTO `dp_admin_attachment` VALUES ('60', '1', 'md2.png', '', 'uploads/images/20200526/6774cb5a77493a1027892d1bc0d177fc.png', '', '', 'image/png', 'png', '1253016', '926ba593b550b526867da886e4c35ae9', '273914aa7838b5e61ea1c2d1f056e54c1756dcff', 'local', '0', '1590482605', '1590482605', '100', '1', '960', '720');
INSERT INTO `dp_admin_attachment` VALUES ('61', '1', 'md9.png', '', 'uploads/images/20200526/adb3a279dfb20fbc5d5b7bb996f18031.png', '', '', 'image/png', 'png', '1275710', '20a9e6fa6cfa30dfedfec011a771690e', '901f68a596de2e553c42f8d69caf9a6912987377', 'local', '0', '1590482605', '1590482605', '100', '1', '960', '720');
INSERT INTO `dp_admin_attachment` VALUES ('62', '1', 'md8.png', '', 'uploads/images/20200526/92183b86a0109756e128666383558ca3.png', '', '', 'image/png', 'png', '1228323', '734d010c3ee323cbb59e56bae62d7a91', 'cf6956a8b1f38217288955a4226bf18730ef5d4c', 'local', '0', '1590482606', '1590482606', '100', '1', '960', '720');
INSERT INTO `dp_admin_attachment` VALUES ('63', '1', 'youshi.png', '', 'uploads/images/20200526/57509a74936a7f81051407af54b120da.png', '', '', 'image/png', 'png', '32725', 'eb487fe43004a228828b628cfaff189f', '7a9e1d8be28fcc95fec621ff959468e814ac25ad', 'local', '0', '1590482769', '1590482769', '100', '1', '600', '445');
INSERT INTO `dp_admin_attachment` VALUES ('64', '1', 'jiameng.jpg', '', 'uploads/images/20200526/0d910705fa0c569214b5126d98748af4.jpg', '', '', 'image/jpeg', 'jpg', '88834', 'a218f41b4d686526c77071ce235553a5', 'ff0e40ec002e7ce6e5f0f3fac21a3411cfbcd339', 'local', '0', '1590482941', '1590482941', '100', '1', '600', '445');
INSERT INTO `dp_admin_attachment` VALUES ('65', '1', 'n3.jpg', 'admin', 'uploads/images/20200527/4ced6f01b0569dffaa7eee259c4a4032.jpg', '', '', 'image/jpeg', 'jpg', '31546', '968a4daeb4ef3f5e8e57dd96a6e8a75a', '1797892469876bf07d87d6a670914499603d25f8', 'local', '0', '1590544909', '1590544909', '100', '1', '500', '333');
INSERT INTO `dp_admin_attachment` VALUES ('66', '1', 'n12.jpg', 'admin', 'uploads/images/20200527/39d1ec7127a2c59c533ade39705a6c10.jpg', '', '', 'image/jpeg', 'jpg', '169888', '0d2034ef16f44b424cc94741a9cd7002', '0f8cb58015af240962d01ffc531dc9a79df5b54d', 'local', '0', '1590545154', '1590545154', '100', '1', '600', '400');
INSERT INTO `dp_admin_attachment` VALUES ('67', '1', 'n4.jpg', 'admin', 'uploads/images/20200527/6a19f24735fe50352dcfd8470385dcbe.jpg', '', '', 'image/jpeg', 'jpg', '41022', '7c10408d470ac1c685960ec15acfa6ee', 'a54649c7ca2001c4da3dfc6c0fae213bb2779729', 'local', '0', '1590545281', '1590545281', '100', '1', '500', '333');
INSERT INTO `dp_admin_attachment` VALUES ('68', '1', 'nx5.jpg', '', 'uploads/images/20200527/1d3cbcd7a65f641a09aaa53845d40f26.jpg', '', '', 'image/jpeg', 'jpg', '277654', '7ad504901a7b8e2f730966e002f08d13', '73dc68d08dc846bc217e979ed88436d9d21de603', 'local', '0', '1590545340', '1590545340', '100', '1', '1042', '625');
INSERT INTO `dp_admin_attachment` VALUES ('69', '1', 'nx6.jpg', '', 'uploads/images/20200527/3225144409b2713d401b04297da30ebd.jpg', '', '', 'image/jpeg', 'jpg', '541388', '4629aaaf94d8cd59aa284ef0a9b30fef', '00023b4b75d2e014c8db2c2c2d88ab5bc75ad2ef', 'local', '0', '1590545402', '1590545402', '100', '1', '1042', '625');
INSERT INTO `dp_admin_attachment` VALUES ('70', '1', 'nx3.jpg', '', 'uploads/images/20200527/3659cb979d2373fab425e38f4fc14e41.jpg', '', '', 'image/jpeg', 'jpg', '463179', 'fb985ea348adc79a490bc8f1618263af', '72cc6a1fed48ec8b5d573c1707aab0e790e67445', 'local', '0', '1590545573', '1590545573', '100', '1', '1042', '626');
INSERT INTO `dp_admin_attachment` VALUES ('71', '1', 'nx4.jpg', '', 'uploads/images/20200527/7c544ce4836e1c776c50df27504046e7.jpg', '', '', 'image/jpeg', 'jpg', '380094', 'aae2f7946928dc3149000a8787bda3d3', 'e493b1632901fdee538ed8b0324a781b5650fa44', 'local', '0', '1590545598', '1590545598', '100', '1', '1042', '626');
INSERT INTO `dp_admin_attachment` VALUES ('72', '1', 'n2.jpg', 'admin', 'uploads/images/20200527/7216f55e9f99d7cf092c6a2c52a115d4.jpg', '', '', 'image/jpeg', 'jpg', '198502', '26c96fd406e0ec039824c0f29ad6d22f', 'de9b0f505662f5580da8e5fa8fa14fb03f6a38fa', 'local', '0', '1590545737', '1590545737', '100', '1', '600', '400');
INSERT INTO `dp_admin_attachment` VALUES ('73', '1', 'nx1.jpg', '', 'uploads/images/20200527/c97db65442ea45fc4afb3c84f381df14.jpg', '', '', 'image/jpeg', 'jpg', '436439', '895c52887bb67ba667bc2d46764c672d', 'a0880460714352cbf727bde8b81c2add0b41cb0a', 'local', '0', '1590545785', '1590545785', '100', '1', '1042', '626');
INSERT INTO `dp_admin_attachment` VALUES ('74', '1', 'nx2.jpg', '', 'uploads/images/20200527/a03f6a7d8dbe399cec1ec009257e5388.jpg', '', '', 'image/jpeg', 'jpg', '372870', '29f394fd1de68a7f6531462e1489be28', '214cad29381c591962f26481ac320ee95fbcd77e', 'local', '0', '1590545795', '1590545795', '100', '1', '1043', '625');
INSERT INTO `dp_admin_attachment` VALUES ('75', '1', 'n1.jpg', 'admin', 'uploads/images/20200527/a3bfe8adda448998dba61ff14df98ff2.jpg', '', '', 'image/jpeg', 'jpg', '218772', 'c279227ff2fca58b711870f1d63d4f4c', '8febdf278bc9e08f534c1f14e544057b9cbe342e', 'local', '0', '1590545935', '1590545935', '100', '1', '600', '400');
INSERT INTO `dp_admin_attachment` VALUES ('76', '1', 'nx9.jpg', '', 'uploads/images/20200527/2be1b56965a90a1aa15da728d313694d.jpg', '', '', 'image/jpeg', 'jpg', '405174', 'e6775b051cda74a70f7bd25db2660019', '3a8a93259a5a5bd493fc22203dd4bf483c01291e', 'local', '0', '1590545967', '1590545967', '100', '1', '1043', '626');
INSERT INTO `dp_admin_attachment` VALUES ('77', '1', 'nx11.jpg', '', 'uploads/images/20200527/b46388ee854b2000b4d2a7f92019b30c.jpg', '', '', 'image/jpeg', 'jpg', '437128', 'c77e973c0418af96266f19fc7f24f769', '6bb69db4cde13e2524fb2359315f1c410123d70e', 'local', '0', '1590545996', '1590545996', '100', '1', '1042', '626');
INSERT INTO `dp_admin_attachment` VALUES ('78', '1', 'nx12.jpg', '', 'uploads/images/20200527/cb857dc94ef291d590ad8974a1b8bfe8.jpg', '', '', 'image/jpeg', 'jpg', '412086', 'b944a94c5ee26d331579b6634dd1ae29', '8415ac519140f367b673480f3fe7e182b0b73750', 'local', '0', '1590546010', '1590546010', '100', '1', '1043', '626');
INSERT INTO `dp_admin_attachment` VALUES ('79', '1', 'n13.jpg', 'admin', 'uploads/images/20200527/947a22dd7f61b50a7143fdf8f92b4337.jpg', '', '', 'image/jpeg', 'jpg', '189417', '2ed340dd5bff7cf00f07bc11616e7221', '0259ec5189e2a5b904f71585e165c6799d7a7120', 'local', '0', '1590546167', '1590546167', '100', '1', '600', '400');
INSERT INTO `dp_admin_attachment` VALUES ('80', '1', 'nx10.jpg', '', 'uploads/images/20200527/d2a69083f3aa9062da978b80722c0274.jpg', '', '', 'image/jpeg', 'jpg', '410465', 'ef08477c26a8407d5ffa2b11b3111344', 'fe32c9a7fd7068d8b703a1d3edd69fb16afdeb9a', 'local', '0', '1590546222', '1590546222', '100', '1', '1043', '626');
INSERT INTO `dp_admin_attachment` VALUES ('81', '1', 'n11.jpg', 'admin', 'uploads/images/20200527/7b5bfdb491f69403605015eed2886353.jpg', '', '', 'image/jpeg', 'jpg', '120738', '1bf60891e5b4474e4761f2f20309c954', 'c9dd8a273f459f6281f87d60ee30ee3243c8a2ae', 'local', '0', '1590546577', '1590546577', '100', '1', '600', '400');
INSERT INTO `dp_admin_attachment` VALUES ('82', '1', 'nx7.jpg', '', 'uploads/images/20200527/2ceb6cee663bad9956691a54e7ba5a39.jpg', '', '', 'image/jpeg', 'jpg', '280981', '1712c2f9b9924286ccaa431a17afbe5c', 'e7e990ea788714089f4e7a3f53115ea79e639661', 'local', '0', '1590546608', '1590546608', '100', '1', '1043', '625');
INSERT INTO `dp_admin_attachment` VALUES ('83', '1', 'nx8.jpg', '', 'uploads/images/20200527/e7bb9b5a45cd89ba3a8c5ee383465103.jpg', '', '', 'image/jpeg', 'jpg', '499164', '368b388aa754f9c2f87021979cbc6195', '12475e965f43c632b4f59ed8bfdac6897b928b9b', 'local', '0', '1590546623', '1590546623', '100', '1', '1042', '625');
INSERT INTO `dp_admin_attachment` VALUES ('84', '1', 'n10.jpg', 'admin', 'uploads/images/20200527/1450de4adefa4035d47e5b5b7522b4e7.jpg', '', '', 'image/jpeg', 'jpg', '198725', 'e70f52c55acc6b0d4db643db779180b6', 'c1eec1f604bb5f44fff5700b746e3ce92353d419', 'local', '0', '1590546787', '1590546787', '100', '1', '600', '400');
INSERT INTO `dp_admin_attachment` VALUES ('85', '1', 'n9.jpg', 'admin', 'uploads/images/20200527/b365e2564272424c7d00c4cc4d8b61c9.jpg', '', '', 'image/jpeg', 'jpg', '146771', '3157a0e35d38302b75fed58977f50e05', '46d69fbaa716a5d82d51d29395fafbd7e6365420', 'local', '0', '1590546901', '1590546901', '100', '1', '600', '400');
INSERT INTO `dp_admin_attachment` VALUES ('86', '1', 'n8.jpg', 'admin', 'uploads/images/20200527/10a46d2d00619a21e525a1c9326bad0d.jpg', '', '', 'image/jpeg', 'jpg', '171959', 'd19282d0941fca5bef695ab0b73114d6', '9374ef7fc8214386902057b5224d58a1fd515791', 'local', '0', '1590557445', '1590557445', '100', '1', '600', '400');
INSERT INTO `dp_admin_attachment` VALUES ('87', '1', 'n7.jpg', 'admin', 'uploads/images/20200527/89ace1b913dbce830030d651ae44761d.jpg', '', '', 'image/jpeg', 'jpg', '213175', '962fa0b06bbde0f01cb19d81feea1340', '034c691df8ddfedea6ff2d74a2a47357b2bed697', 'local', '0', '1590557679', '1590557679', '100', '1', '600', '400');
INSERT INTO `dp_admin_attachment` VALUES ('88', '1', 'n6.jpg', 'admin', 'uploads/images/20200527/3ad394f6eca3e9ae66c5d562e179ec98.jpg', '', '', 'image/jpeg', 'jpg', '36285', '265468e4840bdd5b06c52ecb494b840c', 'af5a037cb8c1204c30fa7bafc43d1b3152a2e78c', 'local', '0', '1590557829', '1590557829', '100', '1', '500', '333');
INSERT INTO `dp_admin_attachment` VALUES ('89', '1', 'n5.jpg', 'admin', 'uploads/images/20200527/7addb89867da69a36e8dd9dd1626c716.jpg', '', '', 'image/jpeg', 'jpg', '35338', '5bb705058f6bcb6f43b2a05bae48afef', '34e577ee0293e298dbbb5dfa537fa625cb4d1821', 'local', '0', '1590558069', '1590558069', '100', '1', '500', '333');

-- -----------------------------
-- Table structure for `dp_admin_config`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_config`;
CREATE TABLE `dp_admin_config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '标题',
  `group` varchar(32) NOT NULL DEFAULT '' COMMENT '配置分组',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '类型',
  `value` text NOT NULL COMMENT '配置值',
  `options` text NOT NULL COMMENT '配置项',
  `tips` varchar(256) NOT NULL DEFAULT '' COMMENT '配置提示',
  `ajax_url` varchar(256) NOT NULL DEFAULT '' COMMENT '联动下拉框ajax地址',
  `next_items` varchar(256) NOT NULL DEFAULT '' COMMENT '联动下拉框的下级下拉框名，多个以逗号隔开',
  `param` varchar(32) NOT NULL DEFAULT '' COMMENT '联动下拉框请求参数名',
  `format` varchar(32) NOT NULL DEFAULT '' COMMENT '格式，用于格式文本',
  `table` varchar(32) NOT NULL DEFAULT '' COMMENT '表名，只用于快速联动类型',
  `level` tinyint(2) unsigned NOT NULL DEFAULT '2' COMMENT '联动级别，只用于快速联动类型',
  `key` varchar(32) NOT NULL DEFAULT '' COMMENT '键字段，只用于快速联动类型',
  `option` varchar(32) NOT NULL DEFAULT '' COMMENT '值字段，只用于快速联动类型',
  `pid` varchar(32) NOT NULL DEFAULT '' COMMENT '父级id字段，只用于快速联动类型',
  `ak` varchar(32) NOT NULL DEFAULT '' COMMENT '百度地图appkey',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态：0禁用，1启用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COMMENT='系统配置表';

-- -----------------------------
-- Records of `dp_admin_config`
-- -----------------------------
INSERT INTO `dp_admin_config` VALUES ('1', 'web_site_status', '站点开关', 'base', 'switch', '1', '', '站点关闭后将不能访问，后台可正常登录', '', '', '', '', '', '2', '', '', '', '', '1475240395', '1477403914', '1', '1');
INSERT INTO `dp_admin_config` VALUES ('2', 'web_site_title', '站点标题', 'base', 'text', '海豚PHP', '', '调用方式：<code>config(\'web_site_title\')</code>', '', '', '', '', '', '2', '', '', '', '', '1475240646', '1477710341', '2', '1');
INSERT INTO `dp_admin_config` VALUES ('3', 'web_site_slogan', '站点标语', 'base', 'text', '海豚PHP，极简、极速、极致', '', '站点口号，调用方式：<code>config(\'web_site_slogan\')</code>', '', '', '', '', '', '2', '', '', '', '', '1475240994', '1477710357', '3', '1');
INSERT INTO `dp_admin_config` VALUES ('4', 'web_site_logo', '站点LOGO', 'base', 'image', '', '', '', '', '', '', '', '', '2', '', '', '', '', '1475241067', '1475241067', '4', '1');
INSERT INTO `dp_admin_config` VALUES ('5', 'web_site_description', '站点描述', 'base', 'textarea', '', '', '网站描述，有利于搜索引擎抓取相关信息', '', '', '', '', '', '2', '', '', '', '', '1475241186', '1475241186', '6', '1');
INSERT INTO `dp_admin_config` VALUES ('6', 'web_site_keywords', '站点关键词', 'base', 'text', '海豚PHP、PHP开发框架、后台框架', '', '网站搜索引擎关键字', '', '', '', '', '', '2', '', '', '', '', '1475241328', '1475241328', '7', '1');
INSERT INTO `dp_admin_config` VALUES ('7', 'web_site_copyright', '版权信息', 'base', 'text', 'Copyright © 2015-2017 DolphinPHP All rights reserved.', '', '调用方式：<code>config(\'web_site_copyright\')</code>', '', '', '', '', '', '2', '', '', '', '', '1475241416', '1477710383', '8', '1');
INSERT INTO `dp_admin_config` VALUES ('8', 'web_site_icp', '备案信息', 'base', 'text', '', '', '调用方式：<code>config(\'web_site_icp\')</code>', '', '', '', '', '', '2', '', '', '', '', '1475241441', '1477710441', '9', '1');
INSERT INTO `dp_admin_config` VALUES ('9', 'web_site_statistics', '站点统计', 'base', 'textarea', '', '', '网站统计代码，支持百度、Google、cnzz等，调用方式：<code>config(\'web_site_statistics\')</code>', '', '', '', '', '', '2', '', '', '', '', '1475241498', '1477710455', '10', '1');
INSERT INTO `dp_admin_config` VALUES ('10', 'config_group', '配置分组', 'system', 'array', 'base:基本\r\nsystem:系统\r\nupload:上传\r\ndevelop:开发\r\ndatabase:数据库', '', '', '', '', '', '', '', '2', '', '', '', '', '1475241716', '1477649446', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('11', 'form_item_type', '配置类型', 'system', 'array', 'text:单行文本\r\ntextarea:多行文本\r\nstatic:静态文本\r\npassword:密码\r\ncheckbox:复选框\r\nradio:单选按钮\r\ndate:日期\r\ndatetime:日期+时间\r\nhidden:隐藏\r\nswitch:开关\r\narray:数组\r\nselect:下拉框\r\nlinkage:普通联动下拉框\r\nlinkages:快速联动下拉框\r\nimage:单张图片\r\nimages:多张图片\r\nfile:单个文件\r\nfiles:多个文件\r\nueditor:UEditor 编辑器\r\nwangeditor:wangEditor 编辑器\r\neditormd:markdown 编辑器\r\nckeditor:ckeditor 编辑器\r\nicon:字体图标\r\ntags:标签\r\nnumber:数字\r\nbmap:百度地图\r\ncolorpicker:取色器\r\njcrop:图片裁剪\r\nmasked:格式文本\r\nrange:范围\r\ntime:时间', '', '', '', '', '', '', '', '2', '', '', '', '', '1475241835', '1495853193', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('12', 'upload_file_size', '文件上传大小限制', 'upload', 'text', '0', '', '0为不限制大小，单位：kb', '', '', '', '', '', '2', '', '', '', '', '1475241897', '1477663520', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('13', 'upload_file_ext', '允许上传的文件后缀', 'upload', 'tags', 'doc,docx,xls,xlsx,ppt,pptx,pdf,wps,txt,rar,zip,gz,bz2,7z', '', '多个后缀用逗号隔开，不填写则不限制类型', '', '', '', '', '', '2', '', '', '', '', '1475241975', '1477649489', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('14', 'upload_image_size', '图片上传大小限制', 'upload', 'text', '0', '', '0为不限制大小，单位：kb', '', '', '', '', '', '2', '', '', '', '', '1475242015', '1477663529', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('15', 'upload_image_ext', '允许上传的图片后缀', 'upload', 'tags', 'bmp,jpg,jpeg,png,ico', '', '多个后缀用逗号隔开，不填写则不限制类型', '', '', '', '', '', '2', '', '', '', '', '1475242056', '1477649506', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('16', 'list_rows', '分页数量', 'system', 'number', '20', '', '每页的记录数', '', '', '', '', '', '2', '', '', '', '', '1475242066', '1476074507', '101', '1');
INSERT INTO `dp_admin_config` VALUES ('17', 'system_color', '后台配色方案', 'system', 'radio', 'default', 'default:Default\r\namethyst:Amethyst\r\ncity:City\r\nflat:Flat\r\nmodern:Modern\r\nsmooth:Smooth', '', '', '', '', '', '', '2', '', '', '', '', '1475250066', '1477316689', '102', '1');
INSERT INTO `dp_admin_config` VALUES ('18', 'develop_mode', '开发模式', 'develop', 'radio', '1', '0:关闭\r\n1:开启', '', '', '', '', '', '', '2', '', '', '', '', '1476864205', '1476864231', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('19', 'app_trace', '显示页面Trace', 'develop', 'radio', '1', '0:否\r\n1:是', '', '', '', '', '', '', '2', '', '', '', '', '1476866355', '1476866355', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('21', 'data_backup_path', '数据库备份根路径', 'database', 'text', '../data/', '', '路径必须以 / 结尾', '', '', '', '', '', '2', '', '', '', '', '1477017745', '1477018467', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('22', 'data_backup_part_size', '数据库备份卷大小', 'database', 'text', '20971520', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '', '', '', '', '', '2', '', '', '', '', '1477017886', '1477017886', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('23', 'data_backup_compress', '数据库备份文件是否启用压缩', 'database', 'radio', '1', '0:否\r\n1:是', '压缩备份文件需要PHP环境支持 <code>gzopen</code>, <code>gzwrite</code>函数', '', '', '', '', '', '2', '', '', '', '', '1477017978', '1477018172', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('24', 'data_backup_compress_level', '数据库备份文件压缩级别', 'database', 'radio', '9', '1:最低\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '', '', '', '', '', '2', '', '', '', '', '1477018083', '1477018083', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('25', 'top_menu_max', '顶部导航模块数量', 'system', 'text', '10', '', '设置顶部导航默认显示的模块数量', '', '', '', '', '', '2', '', '', '', '', '1477579289', '1477579289', '103', '1');
INSERT INTO `dp_admin_config` VALUES ('26', 'web_site_logo_text', '站点LOGO文字', 'base', 'image', '', '', '', '', '', '', '', '', '2', '', '', '', '', '1477620643', '1477620643', '5', '1');
INSERT INTO `dp_admin_config` VALUES ('27', 'upload_image_thumb', '缩略图尺寸', 'upload', 'text', '', '', '不填写则不生成缩略图，如需生成 <code>300x300</code> 的缩略图，则填写 <code>300,300</code> ，请注意，逗号必须是英文逗号', '', '', '', '', '', '2', '', '', '', '', '1477644150', '1477649513', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('28', 'upload_image_thumb_type', '缩略图裁剪类型', 'upload', 'radio', '1', '1:等比例缩放\r\n2:缩放后填充\r\n3:居中裁剪\r\n4:左上角裁剪\r\n5:右下角裁剪\r\n6:固定尺寸缩放', '该项配置只有在启用生成缩略图时才生效', '', '', '', '', '', '2', '', '', '', '', '1477646271', '1477649521', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('29', 'upload_thumb_water', '添加水印', 'upload', 'switch', '0', '', '', '', '', '', '', '', '2', '', '', '', '', '1477649648', '1477649648', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('30', 'upload_thumb_water_pic', '水印图片', 'upload', 'image', '', '', '只有开启水印功能才生效', '', '', '', '', '', '2', '', '', '', '', '1477656390', '1477656390', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('31', 'upload_thumb_water_position', '水印位置', 'upload', 'radio', '9', '1:左上角\r\n2:上居中\r\n3:右上角\r\n4:左居中\r\n5:居中\r\n6:右居中\r\n7:左下角\r\n8:下居中\r\n9:右下角', '只有开启水印功能才生效', '', '', '', '', '', '2', '', '', '', '', '1477656528', '1477656528', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('32', 'upload_thumb_water_alpha', '水印透明度', 'upload', 'text', '50', '', '请输入0~100之间的数字，数字越小，透明度越高', '', '', '', '', '', '2', '', '', '', '', '1477656714', '1477661309', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('33', 'wipe_cache_type', '清除缓存类型', 'system', 'checkbox', 'TEMP_PATH', 'TEMP_PATH:应用缓存\r\nLOG_PATH:应用日志\r\nCACHE_PATH:项目模板缓存', '清除缓存时，要删除的缓存类型', '', '', '', '', '', '2', '', '', '', '', '1477727305', '1477727305', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('34', 'captcha_signin', '后台验证码开关', 'system', 'switch', '0', '', '后台登录时是否需要验证码', '', '', '', '', '', '2', '', '', '', '', '1478771958', '1478771958', '99', '1');
INSERT INTO `dp_admin_config` VALUES ('35', 'home_default_module', '前台默认模块', 'system', 'select', 'index', '', '前台默认访问的模块，该模块必须有Index控制器和index方法', '', '', '', '', '', '0', '', '', '', '', '1486714723', '1486715620', '104', '1');
INSERT INTO `dp_admin_config` VALUES ('36', 'minify_status', '开启minify', 'system', 'switch', '0', '', '开启minify会压缩合并js、css文件，可以减少资源请求次数，如果不支持minify，可关闭', '', '', '', '', '', '0', '', '', '', '', '1487035843', '1487035843', '99', '1');
INSERT INTO `dp_admin_config` VALUES ('37', 'upload_driver', '上传驱动', 'upload', 'radio', 'local', 'local:本地', '图片或文件上传驱动', '', '', '', '', '', '0', '', '', '', '', '1501488567', '1501490821', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('38', 'system_log', '系统日志', 'system', 'switch', '1', '', '是否开启系统日志功能', '', '', '', '', '', '0', '', '', '', '', '1512635391', '1512635391', '99', '1');
INSERT INTO `dp_admin_config` VALUES ('39', 'asset_version', '资源版本号', 'develop', 'text', '20200526', '', '可通过修改版号强制用户更新静态文件', '', '', '', '', '', '0', '', '', '', '', '1522143239', '1522143239', '100', '1');

-- -----------------------------
-- Table structure for `dp_admin_hook`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_hook`;
CREATE TABLE `dp_admin_hook` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `plugin` varchar(32) NOT NULL DEFAULT '' COMMENT '钩子来自哪个插件',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子描述',
  `system` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统钩子',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='钩子表';

-- -----------------------------
-- Records of `dp_admin_hook`
-- -----------------------------
INSERT INTO `dp_admin_hook` VALUES ('1', 'admin_index', '', '后台首页', '1', '1468174214', '1477757518', '1');
INSERT INTO `dp_admin_hook` VALUES ('2', 'plugin_index_tab_list', '', '插件扩展tab钩子', '1', '1468174214', '1468174214', '1');
INSERT INTO `dp_admin_hook` VALUES ('3', 'module_index_tab_list', '', '模块扩展tab钩子', '1', '1468174214', '1468174214', '1');
INSERT INTO `dp_admin_hook` VALUES ('4', 'page_tips', '', '每个页面的提示', '1', '1468174214', '1468174214', '1');
INSERT INTO `dp_admin_hook` VALUES ('5', 'signin_footer', '', '登录页面底部钩子', '1', '1479269315', '1479269315', '1');
INSERT INTO `dp_admin_hook` VALUES ('6', 'signin_captcha', '', '登录页面验证码钩子', '1', '1479269315', '1479269315', '1');
INSERT INTO `dp_admin_hook` VALUES ('7', 'signin', '', '登录控制器钩子', '1', '1479386875', '1479386875', '1');
INSERT INTO `dp_admin_hook` VALUES ('8', 'upload_attachment', '', '附件上传钩子', '1', '1501493808', '1501493808', '1');
INSERT INTO `dp_admin_hook` VALUES ('9', 'page_plugin_js', '', '页面插件js钩子', '1', '1503633591', '1503633591', '1');
INSERT INTO `dp_admin_hook` VALUES ('10', 'page_plugin_css', '', '页面插件css钩子', '1', '1503633591', '1503633591', '1');
INSERT INTO `dp_admin_hook` VALUES ('11', 'signin_sso', '', '单点登录钩子', '1', '1503633591', '1503633591', '1');
INSERT INTO `dp_admin_hook` VALUES ('12', 'signout_sso', '', '单点退出钩子', '1', '1503633591', '1503633591', '1');
INSERT INTO `dp_admin_hook` VALUES ('13', 'user_add', '', '添加用户钩子', '1', '1503633591', '1503633591', '1');
INSERT INTO `dp_admin_hook` VALUES ('14', 'user_edit', '', '编辑用户钩子', '1', '1503633591', '1503633591', '1');
INSERT INTO `dp_admin_hook` VALUES ('15', 'user_delete', '', '删除用户钩子', '1', '1503633591', '1503633591', '1');
INSERT INTO `dp_admin_hook` VALUES ('16', 'user_enable', '', '启用用户钩子', '1', '1503633591', '1503633591', '1');
INSERT INTO `dp_admin_hook` VALUES ('17', 'user_disable', '', '禁用用户钩子', '1', '1503633591', '1503633591', '1');

-- -----------------------------
-- Table structure for `dp_admin_hook_plugin`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_hook_plugin`;
CREATE TABLE `dp_admin_hook_plugin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(32) NOT NULL DEFAULT '' COMMENT '钩子id',
  `plugin` varchar(32) NOT NULL DEFAULT '' COMMENT '插件标识',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='钩子-插件对应表';

-- -----------------------------
-- Records of `dp_admin_hook_plugin`
-- -----------------------------
INSERT INTO `dp_admin_hook_plugin` VALUES ('1', 'admin_index', 'SystemInfo', '1477757503', '1477757503', '1', '1');
INSERT INTO `dp_admin_hook_plugin` VALUES ('2', 'admin_index', 'DevTeam', '1477755780', '1477755780', '2', '1');

-- -----------------------------
-- Table structure for `dp_admin_icon`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_icon`;
CREATE TABLE `dp_admin_icon` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '图标名称',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图标css地址',
  `prefix` varchar(32) NOT NULL DEFAULT '' COMMENT '图标前缀',
  `font_family` varchar(32) NOT NULL DEFAULT '' COMMENT '字体名',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='图标表';


-- -----------------------------
-- Table structure for `dp_admin_icon_list`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_icon_list`;
CREATE TABLE `dp_admin_icon_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `icon_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '所属图标id',
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT '图标标题',
  `class` varchar(255) NOT NULL DEFAULT '' COMMENT '图标类名',
  `code` varchar(128) NOT NULL DEFAULT '' COMMENT '图标关键词',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='详细图标列表';


-- -----------------------------
-- Table structure for `dp_admin_log`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_log`;
CREATE TABLE `dp_admin_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` longtext NOT NULL COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `dp_admin_log`
-- -----------------------------
INSERT INTO `dp_admin_log` VALUES ('1', '30', '1', '2130706433', 'admin_menu', '237', '超级管理员 添加了节点：所属模块(admin),所属节点ID(1),节点标题(公共管理),节点链接()', '1', '1590390662');
INSERT INTO `dp_admin_log` VALUES ('2', '30', '1', '2130706433', 'admin_menu', '238', '超级管理员 添加了节点：所属模块(admin),所属节点ID(237),节点标题(公共配置),节点链接(admin/configuration/index)', '1', '1590390701');
INSERT INTO `dp_admin_log` VALUES ('3', '30', '1', '2130706433', 'admin_menu', '239', '超级管理员 添加了节点：所属模块(admin),所属节点ID(238),节点标题(导航栏),节点链接(admin/navigation/index)', '1', '1590390745');
INSERT INTO `dp_admin_log` VALUES ('4', '31', '1', '2130706433', 'admin_menu', '1', '超级管理员 编辑了节点：节点ID(1)', '1', '1590391602');
INSERT INTO `dp_admin_log` VALUES ('5', '42', '1', '2130706433', 'admin_config', '0', '超级管理员 更新了系统设置：分组(upload)', '1', '1590459111');
INSERT INTO `dp_admin_log` VALUES ('6', '35', '1', '2130706433', 'admin_module', '0', '超级管理员 安装了模块：门户', '1', '1590459539');
INSERT INTO `dp_admin_log` VALUES ('7', '42', '1', '2130706433', 'admin_config', '0', '超级管理员 更新了系统设置：分组(develop)', '1', '1590460000');
INSERT INTO `dp_admin_log` VALUES ('8', '42', '1', '2130706433', 'admin_config', '0', '超级管理员 更新了系统设置：分组(develop)', '1', '1590460016');
INSERT INTO `dp_admin_log` VALUES ('9', '42', '1', '2130706433', 'admin_config', '0', '超级管理员 更新了系统设置：分组(upload)', '1', '1590460110');
INSERT INTO `dp_admin_log` VALUES ('10', '30', '1', '2130706433', 'admin_menu', '339', '超级管理员 添加了节点：所属模块(admin),所属节点ID(1),节点标题(产品中心),节点链接()', '1', '1590475576');
INSERT INTO `dp_admin_log` VALUES ('11', '30', '1', '2130706433', 'admin_menu', '340', '超级管理员 添加了节点：所属模块(admin),所属节点ID(339),节点标题(鹿角巷奶茶),节点链接(admin/product/index)', '1', '1590475626');
INSERT INTO `dp_admin_log` VALUES ('12', '30', '1', '2130706433', 'admin_menu', '347', '超级管理员 添加了节点：所属模块(admin),所属节点ID(1),节点标题(文章管理),节点链接()', '1', '1590479531');
INSERT INTO `dp_admin_log` VALUES ('13', '30', '1', '2130706433', 'admin_menu', '348', '超级管理员 添加了节点：所属模块(admin),所属节点ID(347),节点标题(单页管理),节点链接(admin/page/index)', '1', '1590479576');
INSERT INTO `dp_admin_log` VALUES ('14', '30', '1', '2130706433', 'admin_menu', '355', '超级管理员 添加了节点：所属模块(admin),所属节点ID(347),节点标题(新闻资讯),节点链接(admin/news/index)', '1', '1590479606');
INSERT INTO `dp_admin_log` VALUES ('15', '30', '1', '2130706433', 'admin_menu', '2', '超级管理员 添加了节点：所属模块(admin),所属节点ID(0),节点标题(品牌介绍),节点链接(index/page/index)', '1', '1590483141');
INSERT INTO `dp_admin_log` VALUES ('16', '30', '1', '2130706433', 'admin_menu', '3', '超级管理员 添加了节点：所属模块(admin),所属节点ID(0),节点标题(产品中心),节点链接(index/product/index)', '1', '1590483189');
INSERT INTO `dp_admin_log` VALUES ('17', '30', '1', '2130706433', 'admin_menu', '4', '超级管理员 添加了节点：所属模块(admin),所属节点ID(0),节点标题(全球门店),节点链接(index/page/index)', '1', '1590483213');
INSERT INTO `dp_admin_log` VALUES ('18', '30', '1', '2130706433', 'admin_menu', '5', '超级管理员 添加了节点：所属模块(admin),所属节点ID(0),节点标题(项目优势),节点链接(admin/page/index)', '1', '1590483245');
INSERT INTO `dp_admin_log` VALUES ('19', '30', '1', '2130706433', 'admin_menu', '6', '超级管理员 添加了节点：所属模块(admin),所属节点ID(0),节点标题(新闻资讯),节点链接(admin/news/index)', '1', '1590483279');
INSERT INTO `dp_admin_log` VALUES ('20', '30', '1', '2130706433', 'admin_menu', '7', '超级管理员 添加了节点：所属模块(admin),所属节点ID(0),节点标题(加盟扶持),节点链接(index/page/index)', '1', '1590483526');
INSERT INTO `dp_admin_log` VALUES ('21', '31', '1', '2130706433', 'admin_menu', '5', '超级管理员 编辑了节点：节点ID(5)', '1', '1590483543');
INSERT INTO `dp_admin_log` VALUES ('22', '31', '1', '2130706433', 'admin_menu', '6', '超级管理员 编辑了节点：节点ID(6)', '1', '1590483555');
INSERT INTO `dp_admin_log` VALUES ('23', '34', '1', '2130706433', 'admin_menu', '1', '超级管理员 禁用了节点：节点ID(1),节点标题(首页),节点链接(index/index/index)', '1', '1590483589');
INSERT INTO `dp_admin_log` VALUES ('24', '33', '1', '2130706433', 'admin_menu', '1', '超级管理员 启用了节点：节点ID(1),节点标题(首页),节点链接(index/index/index)', '1', '1590483592');
INSERT INTO `dp_admin_log` VALUES ('25', '34', '1', '2130706433', 'admin_menu', '1', '超级管理员 禁用了节点：节点ID(1),节点标题(首页),节点链接(index/index/index)', '1', '1590483594');
INSERT INTO `dp_admin_log` VALUES ('26', '33', '1', '2130706433', 'admin_menu', '1', '超级管理员 启用了节点：节点ID(1),节点标题(首页),节点链接(index/index/index)', '1', '1590483627');
INSERT INTO `dp_admin_log` VALUES ('27', '30', '1', '2130706433', 'admin_menu', '8', '超级管理员 添加了节点：所属模块(admin),所属节点ID(0),节点标题(测试),节点链接(index/page/index)', '1', '1590543200');
INSERT INTO `dp_admin_log` VALUES ('28', '31', '1', '2130706433', 'admin_menu', '8', '超级管理员 编辑了节点：节点ID(8)', '1', '1590562456');
INSERT INTO `dp_admin_log` VALUES ('29', '30', '1', '2130706433', 'admin_menu', '362', '超级管理员 添加了节点：所属模块(admin),所属节点ID(1),节点标题(关于我们),节点链接()', '1', '1590566305');
INSERT INTO `dp_admin_log` VALUES ('30', '30', '1', '2130706433', 'admin_menu', '363', '超级管理员 添加了节点：所属模块(admin),所属节点ID(362),节点标题(留言管理),节点链接(admin/message/index)', '1', '1590566348');
INSERT INTO `dp_admin_log` VALUES ('31', '32', '1', '2130706433', 'admin_menu', '364', '超级管理员 删除了节点：节点ID(364),节点标题(新增),节点链接(admin/message/add)', '1', '1590566363');
INSERT INTO `dp_admin_log` VALUES ('32', '31', '1', '2130706433', 'admin_menu', '365', '超级管理员 编辑了节点：节点ID(365)', '1', '1590566395');

-- -----------------------------
-- Table structure for `dp_admin_menu`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_menu`;
CREATE TABLE `dp_admin_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上级菜单id',
  `module` varchar(16) NOT NULL DEFAULT '' COMMENT '模块名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '菜单标题',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '菜单图标',
  `url_type` varchar(16) NOT NULL DEFAULT '' COMMENT '链接类型（link：外链，module：模块）',
  `url_value` varchar(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `url_target` varchar(16) NOT NULL DEFAULT '_self' COMMENT '链接打开方式：_blank,_self',
  `online_hide` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '网站上线后是否隐藏',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `system_menu` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统菜单，系统菜单不可删除',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `params` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=370 DEFAULT CHARSET=utf8 COMMENT='后台菜单表';

-- -----------------------------
-- Records of `dp_admin_menu`
-- -----------------------------
INSERT INTO `dp_admin_menu` VALUES ('1', '0', 'admin', '首页', 'fa fa-fw fa-home', 'module_admin', 'admin/index/index', '_self', '0', '1467617722', '1477710540', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('2', '1', 'admin', '快捷操作', 'fa fa-fw fa-folder-open-o', 'module_admin', '', '_self', '0', '1467618170', '1590391365', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('3', '2', 'admin', '清空缓存', 'fa fa-fw fa-trash-o', 'module_admin', 'admin/index/wipecache', '_self', '0', '1467618273', '1590391365', '3', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('4', '0', 'admin', '系统', 'fa fa-fw fa-gear', 'module_admin', 'admin/system/index', '_self', '0', '1467618361', '1477710540', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('5', '4', 'admin', '系统功能', 'si si-wrench', 'module_admin', '', '_self', '0', '1467618441', '1590391365', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('6', '5', 'admin', '系统设置', 'fa fa-fw fa-wrench', 'module_admin', 'admin/system/index', '_self', '0', '1467618490', '1590391365', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('7', '5', 'admin', '配置管理', 'fa fa-fw fa-gears', 'module_admin', 'admin/config/index', '_self', '0', '1467618618', '1590391365', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('8', '7', 'admin', '新增', '', 'module_admin', 'admin/config/add', '_self', '0', '1467618648', '1590391365', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('9', '7', 'admin', '编辑', '', 'module_admin', 'admin/config/edit', '_self', '0', '1467619566', '1590391365', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('10', '7', 'admin', '删除', '', 'module_admin', 'admin/config/delete', '_self', '0', '1467619583', '1590391365', '3', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('11', '7', 'admin', '启用', '', 'module_admin', 'admin/config/enable', '_self', '0', '1467619609', '1590391365', '4', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('12', '7', 'admin', '禁用', '', 'module_admin', 'admin/config/disable', '_self', '0', '1467619637', '1590391365', '5', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('13', '5', 'admin', '节点管理', 'fa fa-fw fa-bars', 'module_admin', 'admin/menu/index', '_self', '0', '1467619882', '1590391365', '3', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('14', '13', 'admin', '新增', '', 'module_admin', 'admin/menu/add', '_self', '0', '1467619902', '1590391365', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('15', '13', 'admin', '编辑', '', 'module_admin', 'admin/menu/edit', '_self', '0', '1467620331', '1590391365', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('16', '13', 'admin', '删除', '', 'module_admin', 'admin/menu/delete', '_self', '0', '1467620363', '1590391365', '3', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('17', '13', 'admin', '启用', '', 'module_admin', 'admin/menu/enable', '_self', '0', '1467620386', '1590391365', '4', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('18', '13', 'admin', '禁用', '', 'module_admin', 'admin/menu/disable', '_self', '0', '1467620404', '1590391365', '5', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('19', '68', 'user', '权限管理', 'fa fa-fw fa-key', 'module_admin', '', '_self', '0', '1467688065', '1477710702', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('20', '19', 'user', '用户管理', 'fa fa-fw fa-user', 'module_admin', 'user/index/index', '_self', '0', '1467688137', '1477710702', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('21', '20', 'user', '新增', '', 'module_admin', 'user/index/add', '_self', '0', '1467688177', '1477710702', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('22', '20', 'user', '编辑', '', 'module_admin', 'user/index/edit', '_self', '0', '1467688202', '1477710702', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('23', '20', 'user', '删除', '', 'module_admin', 'user/index/delete', '_self', '0', '1467688219', '1477710702', '3', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('24', '20', 'user', '启用', '', 'module_admin', 'user/index/enable', '_self', '0', '1467688238', '1477710702', '4', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('25', '20', 'user', '禁用', '', 'module_admin', 'user/index/disable', '_self', '0', '1467688256', '1477710702', '5', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('211', '64', 'admin', '日志详情', '', 'module_admin', 'admin/log/details', '_self', '0', '1480299320', '1590391365', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('32', '4', 'admin', '扩展中心', 'si si-social-dropbox', 'module_admin', '', '_self', '0', '1467688853', '1590391365', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('33', '32', 'admin', '模块管理', 'fa fa-fw fa-th-large', 'module_admin', 'admin/module/index', '_self', '0', '1467689008', '1590391365', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('34', '33', 'admin', '导入', '', 'module_admin', 'admin/module/import', '_self', '0', '1467689153', '1590391365', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('35', '33', 'admin', '导出', '', 'module_admin', 'admin/module/export', '_self', '0', '1467689173', '1590391365', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('36', '33', 'admin', '安装', '', 'module_admin', 'admin/module/install', '_self', '0', '1467689192', '1590391365', '3', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('37', '33', 'admin', '卸载', '', 'module_admin', 'admin/module/uninstall', '_self', '0', '1467689241', '1590391365', '4', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('38', '33', 'admin', '启用', '', 'module_admin', 'admin/module/enable', '_self', '0', '1467689294', '1590391365', '5', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('39', '33', 'admin', '禁用', '', 'module_admin', 'admin/module/disable', '_self', '0', '1467689312', '1590391365', '6', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('40', '33', 'admin', '更新', '', 'module_admin', 'admin/module/update', '_self', '0', '1467689341', '1590391365', '7', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('41', '32', 'admin', '插件管理', 'fa fa-fw fa-puzzle-piece', 'module_admin', 'admin/plugin/index', '_self', '0', '1467689527', '1590391365', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('42', '41', 'admin', '导入', '', 'module_admin', 'admin/plugin/import', '_self', '0', '1467689650', '1590391365', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('43', '41', 'admin', '导出', '', 'module_admin', 'admin/plugin/export', '_self', '0', '1467689665', '1590391365', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('44', '41', 'admin', '安装', '', 'module_admin', 'admin/plugin/install', '_self', '0', '1467689680', '1590391365', '3', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('45', '41', 'admin', '卸载', '', 'module_admin', 'admin/plugin/uninstall', '_self', '0', '1467689700', '1590391365', '4', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('46', '41', 'admin', '启用', '', 'module_admin', 'admin/plugin/enable', '_self', '0', '1467689730', '1590391365', '5', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('47', '41', 'admin', '禁用', '', 'module_admin', 'admin/plugin/disable', '_self', '0', '1467689747', '1590391365', '6', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('48', '41', 'admin', '设置', '', 'module_admin', 'admin/plugin/config', '_self', '0', '1467689789', '1590391365', '7', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('49', '41', 'admin', '管理', '', 'module_admin', 'admin/plugin/manage', '_self', '0', '1467689846', '1590391365', '8', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('50', '5', 'admin', '附件管理', 'fa fa-fw fa-cloud-upload', 'module_admin', 'admin/attachment/index', '_self', '0', '1467690161', '1590391365', '4', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('51', '70', 'admin', '文件上传', '', 'module_admin', 'admin/attachment/upload', '_self', '0', '1467690240', '1590391365', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('52', '50', 'admin', '下载', '', 'module_admin', 'admin/attachment/download', '_self', '0', '1467690334', '1590391365', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('53', '50', 'admin', '启用', '', 'module_admin', 'admin/attachment/enable', '_self', '0', '1467690352', '1590391365', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('54', '50', 'admin', '禁用', '', 'module_admin', 'admin/attachment/disable', '_self', '0', '1467690369', '1590391365', '3', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('55', '50', 'admin', '删除', '', 'module_admin', 'admin/attachment/delete', '_self', '0', '1467690396', '1590391365', '4', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('56', '41', 'admin', '删除', '', 'module_admin', 'admin/plugin/delete', '_self', '0', '1467858065', '1590391365', '11', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('57', '41', 'admin', '编辑', '', 'module_admin', 'admin/plugin/edit', '_self', '0', '1467858092', '1590391365', '10', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('60', '41', 'admin', '新增', '', 'module_admin', 'admin/plugin/add', '_self', '0', '1467858421', '1590391365', '9', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('61', '41', 'admin', '执行', '', 'module_admin', 'admin/plugin/execute', '_self', '0', '1467879016', '1590391365', '12', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('62', '13', 'admin', '保存', '', 'module_admin', 'admin/menu/save', '_self', '0', '1468073039', '1590391365', '6', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('64', '5', 'admin', '系统日志', 'fa fa-fw fa-book', 'module_admin', 'admin/log/index', '_self', '0', '1476111944', '1590391365', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('65', '5', 'admin', '数据库管理', 'fa fa-fw fa-database', 'module_admin', 'admin/database/index', '_self', '0', '1476111992', '1590391365', '7', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('66', '32', 'admin', '数据包管理', 'fa fa-fw fa-database', 'module_admin', 'admin/packet/index', '_self', '0', '1476112326', '1590391365', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('67', '19', 'user', '角色管理', 'fa fa-fw fa-users', 'module_admin', 'user/role/index', '_self', '0', '1476113025', '1477710702', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('68', '0', 'user', '用户', 'fa fa-fw fa-user', 'module_admin', 'user/index/index', '_self', '0', '1476193348', '1477710540', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('69', '32', 'admin', '钩子管理', 'fa fa-fw fa-anchor', 'module_admin', 'admin/hook/index', '_self', '0', '1476236193', '1590391365', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('70', '2', 'admin', '后台首页', 'fa fa-fw fa-tachometer', 'module_admin', 'admin/index/index', '_self', '0', '1476237472', '1590391365', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('71', '67', 'user', '新增', '', 'module_admin', 'user/role/add', '_self', '0', '1476256935', '1477710702', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('72', '67', 'user', '编辑', '', 'module_admin', 'user/role/edit', '_self', '0', '1476256968', '1477710702', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('73', '67', 'user', '删除', '', 'module_admin', 'user/role/delete', '_self', '0', '1476256993', '1477710702', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('74', '67', 'user', '启用', '', 'module_admin', 'user/role/enable', '_self', '0', '1476257023', '1477710702', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('75', '67', 'user', '禁用', '', 'module_admin', 'user/role/disable', '_self', '0', '1476257046', '1477710702', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('76', '20', 'user', '授权', '', 'module_admin', 'user/index/access', '_self', '0', '1476375187', '1477710702', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('77', '69', 'admin', '新增', '', 'module_admin', 'admin/hook/add', '_self', '0', '1476668971', '1590391365', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('78', '69', 'admin', '编辑', '', 'module_admin', 'admin/hook/edit', '_self', '0', '1476669006', '1590391365', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('79', '69', 'admin', '删除', '', 'module_admin', 'admin/hook/delete', '_self', '0', '1476669375', '1590391365', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('80', '69', 'admin', '启用', '', 'module_admin', 'admin/hook/enable', '_self', '0', '1476669427', '1590391365', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('81', '69', 'admin', '禁用', '', 'module_admin', 'admin/hook/disable', '_self', '0', '1476669564', '1590391365', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('183', '66', 'admin', '安装', '', 'module_admin', 'admin/packet/install', '_self', '0', '1476851362', '1590391365', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('184', '66', 'admin', '卸载', '', 'module_admin', 'admin/packet/uninstall', '_self', '0', '1476851382', '1590391365', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('185', '5', 'admin', '行为管理', 'fa fa-fw fa-bug', 'module_admin', 'admin/action/index', '_self', '0', '1476882441', '1590391365', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('186', '185', 'admin', '新增', '', 'module_admin', 'admin/action/add', '_self', '0', '1476884439', '1590391365', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('187', '185', 'admin', '编辑', '', 'module_admin', 'admin/action/edit', '_self', '0', '1476884464', '1590391365', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('188', '185', 'admin', '启用', '', 'module_admin', 'admin/action/enable', '_self', '0', '1476884493', '1590391365', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('189', '185', 'admin', '禁用', '', 'module_admin', 'admin/action/disable', '_self', '0', '1476884534', '1590391365', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('190', '185', 'admin', '删除', '', 'module_admin', 'admin/action/delete', '_self', '0', '1476884551', '1590391365', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('191', '65', 'admin', '备份数据库', '', 'module_admin', 'admin/database/export', '_self', '0', '1476972746', '1590391365', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('192', '65', 'admin', '还原数据库', '', 'module_admin', 'admin/database/import', '_self', '0', '1476972772', '1590391365', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('193', '65', 'admin', '优化表', '', 'module_admin', 'admin/database/optimize', '_self', '0', '1476972800', '1590391365', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('194', '65', 'admin', '修复表', '', 'module_admin', 'admin/database/repair', '_self', '0', '1476972825', '1590391365', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('195', '65', 'admin', '删除备份', '', 'module_admin', 'admin/database/delete', '_self', '0', '1476973457', '1590391365', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('210', '41', 'admin', '快速编辑', '', 'module_admin', 'admin/plugin/quickedit', '_self', '0', '1477713981', '1590391365', '13', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('209', '185', 'admin', '快速编辑', '', 'module_admin', 'admin/action/quickedit', '_self', '0', '1477713939', '1590391365', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('208', '7', 'admin', '快速编辑', '', 'module_admin', 'admin/config/quickedit', '_self', '0', '1477713808', '1590391365', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('207', '69', 'admin', '快速编辑', '', 'module_admin', 'admin/hook/quickedit', '_self', '0', '1477713770', '1590391365', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('212', '2', 'admin', '个人设置', 'fa fa-fw fa-user', 'module_admin', 'admin/index/profile', '_self', '0', '1489049767', '1590391365', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('213', '70', 'admin', '检查版本更新', '', 'module_admin', 'admin/index/checkupdate', '_self', '0', '1490588610', '1590391365', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('214', '68', 'user', '消息管理', 'fa fa-fw fa-comments-o', 'module_admin', '', '_self', '0', '1520492129', '1520492129', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('215', '214', 'user', '消息列表', 'fa fa-fw fa-th-list', 'module_admin', 'user/message/index', '_self', '0', '1520492195', '1520492195', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('216', '215', 'user', '新增', '', 'module_admin', 'user/message/add', '_self', '0', '1520492195', '1520492195', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('217', '215', 'user', '编辑', '', 'module_admin', 'user/message/edit', '_self', '0', '1520492195', '1520492195', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('218', '215', 'user', '删除', '', 'module_admin', 'user/message/delete', '_self', '0', '1520492195', '1520492195', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('219', '215', 'user', '启用', '', 'module_admin', 'user/message/enable', '_self', '0', '1520492195', '1520492195', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('220', '215', 'user', '禁用', '', 'module_admin', 'user/message/disable', '_self', '0', '1520492195', '1520492195', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('221', '215', 'user', '快速编辑', '', 'module_admin', 'user/message/quickedit', '_self', '0', '1520492195', '1520492195', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('222', '2', 'admin', '消息中心', 'fa fa-fw fa-comments-o', 'module_admin', 'admin/message/index', '_self', '0', '1520495992', '1590391365', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('223', '222', 'admin', '删除', '', 'module_admin', 'admin/message/delete', '_self', '0', '1520495992', '1590391365', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('224', '222', 'admin', '启用', '', 'module_admin', 'admin/message/enable', '_self', '0', '1520495992', '1590391365', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('225', '32', 'admin', '图标管理', 'fa fa-fw fa-tint', 'module_admin', 'admin/icon/index', '_self', '0', '1520908295', '1590391365', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('226', '225', 'admin', '新增', '', 'module_admin', 'admin/icon/add', '_self', '0', '1520908295', '1590391365', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('227', '225', 'admin', '编辑', '', 'module_admin', 'admin/icon/edit', '_self', '0', '1520908295', '1590391365', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('228', '225', 'admin', '删除', '', 'module_admin', 'admin/icon/delete', '_self', '0', '1520908295', '1590391365', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('229', '225', 'admin', '启用', '', 'module_admin', 'admin/icon/enable', '_self', '0', '1520908295', '1590391365', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('230', '225', 'admin', '禁用', '', 'module_admin', 'admin/icon/disable', '_self', '0', '1520908295', '1590391365', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('231', '225', 'admin', '快速编辑', '', 'module_admin', 'admin/icon/quickedit', '_self', '0', '1520908295', '1590391365', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('232', '225', 'admin', '图标列表', '', 'module_admin', 'admin/icon/items', '_self', '0', '1520923368', '1590391365', '7', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('233', '225', 'admin', '更新图标', '', 'module_admin', 'admin/icon/reload', '_self', '0', '1520931908', '1590391365', '8', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('234', '20', 'user', '快速编辑', '', 'module_admin', 'user/index/quickedit', '_self', '0', '1526028258', '1526028258', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('235', '67', 'user', '快速编辑', '', 'module_admin', 'user/role/quickedit', '_self', '0', '1526028282', '1526028282', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('236', '6', 'admin', '快速编辑', '', 'module_admin', 'admin/system/quickedit', '_self', '0', '1559054310', '1590391365', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('237', '1', 'admin', '公共管理', 'fa fa-fw fa-th-large', 'module_admin', '', '_self', '0', '1590390662', '1590391365', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('238', '237', 'admin', '公共配置', 'fa fa-fw fa-list', 'module_admin', 'admin/configuration/index', '_self', '0', '1590390701', '1590391365', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('239', '237', 'admin', '导航栏', 'fa fa-fw fa-list', 'module_admin', 'admin/navigation/index', '_self', '0', '1590390746', '1590391365', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('240', '239', 'admin', '新增', '', 'module_admin', 'admin/navigation/add', '_self', '0', '1590390745', '1590391365', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('241', '239', 'admin', '编辑', '', 'module_admin', 'admin/navigation/edit', '_self', '0', '1590390745', '1590391365', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('242', '239', 'admin', '删除', '', 'module_admin', 'admin/navigation/delete', '_self', '0', '1590390745', '1590391365', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('243', '239', 'admin', '启用', '', 'module_admin', 'admin/navigation/enable', '_self', '0', '1590390745', '1590391365', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('244', '239', 'admin', '禁用', '', 'module_admin', 'admin/navigation/disable', '_self', '0', '1590390745', '1590391365', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('245', '239', 'admin', '快速编辑', '', 'module_admin', 'admin/navigation/quickedit', '_self', '0', '1590390745', '1590391365', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('246', '0', 'cms', '门户', 'fa fa-fw fa-newspaper-o', 'module_admin', 'cms/index/index', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('247', '246', 'cms', '常用操作', 'fa fa-fw fa-folder-open-o', 'module_admin', '', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('248', '247', 'cms', '仪表盘', 'fa fa-fw fa-tachometer', 'module_admin', 'cms/index/index', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('249', '247', 'cms', '发布文档', 'fa fa-fw fa-plus', 'module_admin', 'cms/document/add', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('250', '247', 'cms', '文档列表', 'fa fa-fw fa-list', 'module_admin', 'cms/document/index', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('251', '250', 'cms', '编辑', '', 'module_admin', 'cms/document/edit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('252', '250', 'cms', '删除', '', 'module_admin', 'cms/document/delete', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('253', '250', 'cms', '启用', '', 'module_admin', 'cms/document/enable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('254', '250', 'cms', '禁用', '', 'module_admin', 'cms/document/disable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('255', '250', 'cms', '快速编辑', '', 'module_admin', 'cms/document/quickedit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('256', '247', 'cms', '单页管理', 'fa fa-fw fa-file-word-o', 'module_admin', 'cms/page/index', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('257', '256', 'cms', '新增', '', 'module_admin', 'cms/page/add', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('258', '256', 'cms', '编辑', '', 'module_admin', 'cms/page/edit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('259', '256', 'cms', '删除', '', 'module_admin', 'cms/page/delete', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('260', '256', 'cms', '启用', '', 'module_admin', 'cms/page/enable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('261', '256', 'cms', '禁用', '', 'module_admin', 'cms/page/disable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('262', '256', 'cms', '快速编辑', '', 'module_admin', 'cms/page/quickedit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('263', '247', 'cms', '回收站', 'fa fa-fw fa-recycle', 'module_admin', 'cms/recycle/index', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('264', '263', 'cms', '删除', '', 'module_admin', 'cms/recycle/delete', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('265', '263', 'cms', '还原', '', 'module_admin', 'cms/recycle/restore', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('266', '246', 'cms', '内容管理', 'fa fa-fw fa-th-list', 'module_admin', '', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('267', '246', 'cms', '营销管理', 'fa fa-fw fa-money', 'module_admin', '', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('268', '267', 'cms', '广告管理', 'fa fa-fw fa-handshake-o', 'module_admin', 'cms/advert/index', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('269', '268', 'cms', '新增', '', 'module_admin', 'cms/advert/add', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('270', '268', 'cms', '编辑', '', 'module_admin', 'cms/advert/edit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('271', '268', 'cms', '删除', '', 'module_admin', 'cms/advert/delete', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('272', '268', 'cms', '启用', '', 'module_admin', 'cms/advert/enable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('273', '268', 'cms', '禁用', '', 'module_admin', 'cms/advert/disable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('274', '268', 'cms', '快速编辑', '', 'module_admin', 'cms/advert/quickedit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('275', '268', 'cms', '广告分类', '', 'module_admin', 'cms/advert_type/index', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('276', '275', 'cms', '新增', '', 'module_admin', 'cms/advert_type/add', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('277', '275', 'cms', '编辑', '', 'module_admin', 'cms/advert_type/edit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('278', '275', 'cms', '删除', '', 'module_admin', 'cms/advert_type/delete', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('279', '275', 'cms', '启用', '', 'module_admin', 'cms/advert_type/enable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('280', '275', 'cms', '禁用', '', 'module_admin', 'cms/advert_type/disable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('281', '275', 'cms', '快速编辑', '', 'module_admin', 'cms/advert_type/quickedit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('282', '267', 'cms', '滚动图片', 'fa fa-fw fa-photo', 'module_admin', 'cms/slider/index', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('283', '282', 'cms', '新增', '', 'module_admin', 'cms/slider/add', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('284', '282', 'cms', '编辑', '', 'module_admin', 'cms/slider/edit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('285', '282', 'cms', '删除', '', 'module_admin', 'cms/slider/delete', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('286', '282', 'cms', '启用', '', 'module_admin', 'cms/slider/enable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('287', '282', 'cms', '禁用', '', 'module_admin', 'cms/slider/disable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('288', '282', 'cms', '快速编辑', '', 'module_admin', 'cms/slider/quickedit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('289', '267', 'cms', '友情链接', 'fa fa-fw fa-link', 'module_admin', 'cms/link/index', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('290', '289', 'cms', '新增', '', 'module_admin', 'cms/link/add', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('291', '289', 'cms', '编辑', '', 'module_admin', 'cms/link/edit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('292', '289', 'cms', '删除', '', 'module_admin', 'cms/link/delete', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('293', '289', 'cms', '启用', '', 'module_admin', 'cms/link/enable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('294', '289', 'cms', '禁用', '', 'module_admin', 'cms/link/disable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('295', '289', 'cms', '快速编辑', '', 'module_admin', 'cms/link/quickedit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('296', '267', 'cms', '客服管理', 'fa fa-fw fa-commenting', 'module_admin', 'cms/support/index', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('297', '296', 'cms', '新增', '', 'module_admin', 'cms/support/add', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('298', '296', 'cms', '编辑', '', 'module_admin', 'cms/support/edit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('299', '296', 'cms', '删除', '', 'module_admin', 'cms/support/delete', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('300', '296', 'cms', '启用', '', 'module_admin', 'cms/support/enable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('301', '296', 'cms', '禁用', '', 'module_admin', 'cms/support/disable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('302', '296', 'cms', '快速编辑', '', 'module_admin', 'cms/support/quickedit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('303', '246', 'cms', '门户设置', 'fa fa-fw fa-sliders', 'module_admin', '', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('304', '303', 'cms', '栏目分类', 'fa fa-fw fa-sitemap', 'module_admin', 'cms/column/index', '_self', '1', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('305', '304', 'cms', '新增', '', 'module_admin', 'cms/column/add', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('306', '304', 'cms', '编辑', '', 'module_admin', 'cms/column/edit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('307', '304', 'cms', '删除', '', 'module_admin', 'cms/column/delete', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('308', '304', 'cms', '启用', '', 'module_admin', 'cms/column/enable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('309', '304', 'cms', '禁用', '', 'module_admin', 'cms/column/disable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('310', '304', 'cms', '快速编辑', '', 'module_admin', 'cms/column/quickedit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('311', '303', 'cms', '内容模型', 'fa fa-fw fa-th-large', 'module_admin', 'cms/model/index', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('312', '311', 'cms', '新增', '', 'module_admin', 'cms/model/add', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('313', '311', 'cms', '编辑', '', 'module_admin', 'cms/model/edit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('314', '311', 'cms', '删除', '', 'module_admin', 'cms/model/delete', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('315', '311', 'cms', '启用', '', 'module_admin', 'cms/model/enable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('316', '311', 'cms', '禁用', '', 'module_admin', 'cms/model/disable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('317', '311', 'cms', '快速编辑', '', 'module_admin', 'cms/model/quickedit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('318', '311', 'cms', '字段管理', '', 'module_admin', 'cms/field/index', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('319', '318', 'cms', '新增', '', 'module_admin', 'cms/field/add', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('320', '318', 'cms', '编辑', '', 'module_admin', 'cms/field/edit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('321', '318', 'cms', '删除', '', 'module_admin', 'cms/field/delete', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('322', '318', 'cms', '启用', '', 'module_admin', 'cms/field/enable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('323', '318', 'cms', '禁用', '', 'module_admin', 'cms/field/disable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('324', '318', 'cms', '快速编辑', '', 'module_admin', 'cms/field/quickedit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('325', '303', 'cms', '导航管理', 'fa fa-fw fa-map-signs', 'module_admin', 'cms/nav/index', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('326', '325', 'cms', '新增', '', 'module_admin', 'cms/nav/add', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('327', '325', 'cms', '编辑', '', 'module_admin', 'cms/nav/edit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('328', '325', 'cms', '删除', '', 'module_admin', 'cms/nav/delete', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('329', '325', 'cms', '启用', '', 'module_admin', 'cms/nav/enable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('330', '325', 'cms', '禁用', '', 'module_admin', 'cms/nav/disable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('331', '325', 'cms', '快速编辑', '', 'module_admin', 'cms/nav/quickedit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('332', '325', 'cms', '菜单管理', '', 'module_admin', 'cms/menu/index', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('333', '332', 'cms', '新增', '', 'module_admin', 'cms/menu/add', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('334', '332', 'cms', '编辑', '', 'module_admin', 'cms/menu/edit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('335', '332', 'cms', '删除', '', 'module_admin', 'cms/menu/delete', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('336', '332', 'cms', '启用', '', 'module_admin', 'cms/menu/enable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('337', '332', 'cms', '禁用', '', 'module_admin', 'cms/menu/disable', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('338', '332', 'cms', '快速编辑', '', 'module_admin', 'cms/menu/quickedit', '_self', '0', '1590459540', '1590459540', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('339', '1', 'admin', '产品中心', 'fa fa-fw fa-th-large', 'module_admin', '', '_self', '0', '1590475576', '1590475576', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('340', '339', 'admin', '鹿角巷奶茶', 'fa fa-fw fa-list', 'module_admin', 'admin/product/index', '_self', '0', '1590475626', '1590475626', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('341', '340', 'admin', '新增', '', 'module_admin', 'admin/product/add', '_self', '0', '1590475626', '1590475626', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('342', '340', 'admin', '编辑', '', 'module_admin', 'admin/product/edit', '_self', '0', '1590475626', '1590475626', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('343', '340', 'admin', '删除', '', 'module_admin', 'admin/product/delete', '_self', '0', '1590475626', '1590475626', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('344', '340', 'admin', '启用', '', 'module_admin', 'admin/product/enable', '_self', '0', '1590475626', '1590475626', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('345', '340', 'admin', '禁用', '', 'module_admin', 'admin/product/disable', '_self', '0', '1590475626', '1590475626', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('346', '340', 'admin', '快速编辑', '', 'module_admin', 'admin/product/quickedit', '_self', '0', '1590475626', '1590475626', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('347', '1', 'admin', '文章管理', 'fa fa-fw fa-th-large', 'module_admin', '', '_self', '0', '1590479531', '1590479531', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('348', '347', 'admin', '单页管理', 'fa fa-fw fa-list', 'module_admin', 'admin/page/index', '_self', '0', '1590479576', '1590479576', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('349', '348', 'admin', '新增', '', 'module_admin', 'admin/page/add', '_self', '0', '1590479576', '1590479576', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('350', '348', 'admin', '编辑', '', 'module_admin', 'admin/page/edit', '_self', '0', '1590479576', '1590479576', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('351', '348', 'admin', '删除', '', 'module_admin', 'admin/page/delete', '_self', '0', '1590479576', '1590479576', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('352', '348', 'admin', '启用', '', 'module_admin', 'admin/page/enable', '_self', '0', '1590479576', '1590479576', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('353', '348', 'admin', '禁用', '', 'module_admin', 'admin/page/disable', '_self', '0', '1590479576', '1590479576', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('354', '348', 'admin', '快速编辑', '', 'module_admin', 'admin/page/quickedit', '_self', '0', '1590479576', '1590479576', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('355', '347', 'admin', '新闻资讯', 'fa fa-fw fa-list', 'module_admin', 'admin/news/index', '_self', '0', '1590479606', '1590479606', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('356', '355', 'admin', '新增', '', 'module_admin', 'admin/news/add', '_self', '0', '1590479606', '1590479606', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('357', '355', 'admin', '编辑', '', 'module_admin', 'admin/news/edit', '_self', '0', '1590479606', '1590479606', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('358', '355', 'admin', '删除', '', 'module_admin', 'admin/news/delete', '_self', '0', '1590479606', '1590479606', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('359', '355', 'admin', '启用', '', 'module_admin', 'admin/news/enable', '_self', '0', '1590479606', '1590479606', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('360', '355', 'admin', '禁用', '', 'module_admin', 'admin/news/disable', '_self', '0', '1590479606', '1590479606', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('361', '355', 'admin', '快速编辑', '', 'module_admin', 'admin/news/quickedit', '_self', '0', '1590479606', '1590479606', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('362', '1', 'admin', '关于我们', 'fa fa-fw fa-th-large', 'module_admin', '', '_self', '0', '1590566306', '1590566306', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('363', '362', 'admin', '留言管理', 'fa fa-fw fa-list', 'module_admin', 'admin/message/index', '_self', '0', '1590566348', '1590566348', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('365', '363', 'admin', '详情', '', 'module_admin', 'admin/message/details', '_self', '0', '1590566348', '1590566395', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('366', '363', 'admin', '删除', '', 'module_admin', 'admin/message/delete', '_self', '0', '1590566348', '1590566348', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('367', '363', 'admin', '启用', '', 'module_admin', 'admin/message/enable', '_self', '0', '1590566348', '1590566348', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('368', '363', 'admin', '禁用', '', 'module_admin', 'admin/message/disable', '_self', '0', '1590566348', '1590566348', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('369', '363', 'admin', '快速编辑', '', 'module_admin', 'admin/message/quickedit', '_self', '0', '1590566348', '1590566348', '100', '0', '1', '');

-- -----------------------------
-- Table structure for `dp_admin_message`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_message`;
CREATE TABLE `dp_admin_message` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid_receive` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '接收消息的用户id',
  `uid_send` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发送消息的用户id',
  `type` varchar(128) NOT NULL DEFAULT '' COMMENT '消息分类',
  `content` text NOT NULL COMMENT '消息内容',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `read_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '阅读时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='消息表';


-- -----------------------------
-- Table structure for `dp_admin_module`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_module`;
CREATE TABLE `dp_admin_module` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '模块名称（标识）',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '模块标题',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '图标',
  `description` text NOT NULL COMMENT '描述',
  `author` varchar(32) NOT NULL DEFAULT '' COMMENT '作者',
  `author_url` varchar(255) NOT NULL DEFAULT '' COMMENT '作者主页',
  `config` text COMMENT '配置信息',
  `access` text COMMENT '授权配置',
  `version` varchar(16) NOT NULL DEFAULT '' COMMENT '版本号',
  `identifier` varchar(64) NOT NULL DEFAULT '' COMMENT '模块唯一标识符',
  `system_module` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统模块',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='模块表';

-- -----------------------------
-- Records of `dp_admin_module`
-- -----------------------------
INSERT INTO `dp_admin_module` VALUES ('1', 'admin', '系统', 'fa fa-fw fa-gear', '系统模块，DolphinPHP的核心模块', 'DolphinPHP', 'http://www.dolphinphp.com', '', '', '1.0.0', 'admin.dolphinphp.module', '1', '1468204902', '1468204902', '100', '1');
INSERT INTO `dp_admin_module` VALUES ('2', 'user', '用户', 'fa fa-fw fa-user', '用户模块，DolphinPHP自带模块', 'DolphinPHP', 'http://www.dolphinphp.com', '', '', '1.0.0', 'user.dolphinphp.module', '1', '1468204902', '1468204902', '100', '1');
INSERT INTO `dp_admin_module` VALUES ('3', 'cms', '门户', 'fa fa-fw fa-newspaper-o', '门户模块', 'CaiWeiMing', 'http://www.dolphinphp.com', '{\"summary\":0,\"contact\":\"<div class=\\\"font-s13 push\\\"><strong>\\u6cb3\\u6e90\\u5e02\\u5353\\u9510\\u79d1\\u6280\\u6709\\u9650\\u516c\\u53f8<\\/strong><br \\/>\\r\\n\\u5730\\u5740\\uff1a\\u6cb3\\u6e90\\u5e02\\u6c5f\\u4e1c\\u65b0\\u533a\\u4e1c\\u73af\\u8def\\u6c47\\u901a\\u82d1D3-H232<br \\/>\\r\\n\\u7535\\u8bdd\\uff1a0762-8910006<br \\/>\\r\\n\\u90ae\\u7bb1\\uff1aadmin@zrthink.com<\\/div>\",\"meta_head\":\"\",\"meta_foot\":\"\",\"support_status\":1,\"support_color\":\"rgba(0,158,232,1)\",\"support_wx\":\"\",\"support_extra\":\"\"}', '{\"column\":{\"title\":\"\\u680f\\u76ee\\u6388\\u6743\",\"nodes\":{\"group\":\"column\",\"table_name\":\"cms_column\",\"primary_key\":\"id\",\"parent_id\":\"pid\",\"node_name\":\"name\"}}}', '1.0.0', 'cms.ming.module', '0', '1590459540', '1590459540', '100', '1');

-- -----------------------------
-- Table structure for `dp_admin_navigation`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_navigation`;
CREATE TABLE `dp_admin_navigation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上级菜单id',
  `module` varchar(16) NOT NULL DEFAULT '' COMMENT '模块名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '菜单标题',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '菜单图标',
  `url_type` varchar(16) NOT NULL DEFAULT '' COMMENT '链接类型（link：外链，module：模块）',
  `url_value` varchar(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `url_target` varchar(16) NOT NULL DEFAULT '_self' COMMENT '链接打开方式：_blank,_self',
  `online_hide` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '网站上线后是否隐藏',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `system_menu` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统菜单，系统菜单不可删除',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `params` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='后台菜单表';

-- -----------------------------
-- Records of `dp_admin_navigation`
-- -----------------------------
INSERT INTO `dp_admin_navigation` VALUES ('1', '0', 'admin', '首页', 'fa fa-fw fa-home', 'module_home', 'index/index/index', '_self', '0', '1467617722', '1590391602', '1', '1', '1', '');
INSERT INTO `dp_admin_navigation` VALUES ('2', '0', 'admin', '品牌介绍', '', 'module_home', 'index/page/index', '_self', '0', '1590483141', '1590483141', '100', '0', '1', 'cat=1');
INSERT INTO `dp_admin_navigation` VALUES ('3', '0', 'admin', '产品中心', '', 'module_home', 'index/product/index', '_self', '0', '1590483189', '1590483189', '100', '0', '1', '');
INSERT INTO `dp_admin_navigation` VALUES ('4', '0', 'admin', '全球门店', '', 'module_home', 'index/page/index', '_self', '0', '1590483213', '1590483213', '100', '0', '1', 'cat=2');
INSERT INTO `dp_admin_navigation` VALUES ('5', '0', 'admin', '项目优势', '', 'module_home', 'index/page/index', '_self', '0', '1590483246', '1590483543', '100', '0', '1', 'cat=3');
INSERT INTO `dp_admin_navigation` VALUES ('6', '0', 'admin', '新闻资讯', '', 'module_home', 'index/news/index', '_self', '0', '1590483280', '1590483555', '100', '0', '1', '');
INSERT INTO `dp_admin_navigation` VALUES ('7', '0', 'admin', '加盟扶持', '', 'module_home', 'index/page/index', '_self', '0', '1590483526', '1590483526', '100', '0', '1', 'cat=4');
INSERT INTO `dp_admin_navigation` VALUES ('8', '0', 'admin', '联系我们', '', 'module_home', 'index/aboutus/index', '_self', '0', '1590543201', '1590562456', '100', '0', '1', '');

-- -----------------------------
-- Table structure for `dp_admin_packet`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_packet`;
CREATE TABLE `dp_admin_packet` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '数据包名',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '数据包标题',
  `author` varchar(32) NOT NULL DEFAULT '' COMMENT '作者',
  `author_url` varchar(255) NOT NULL DEFAULT '' COMMENT '作者url',
  `version` varchar(16) NOT NULL,
  `tables` text NOT NULL COMMENT '数据表名',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='数据包表';


-- -----------------------------
-- Table structure for `dp_admin_plugin`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_plugin`;
CREATE TABLE `dp_admin_plugin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '插件名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '插件标题',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '图标',
  `description` text NOT NULL COMMENT '插件描述',
  `author` varchar(32) NOT NULL DEFAULT '' COMMENT '作者',
  `author_url` varchar(255) NOT NULL DEFAULT '' COMMENT '作者主页',
  `config` text NOT NULL COMMENT '配置信息',
  `version` varchar(16) NOT NULL DEFAULT '' COMMENT '版本号',
  `identifier` varchar(64) NOT NULL DEFAULT '' COMMENT '插件唯一标识符',
  `admin` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台管理',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `dp_admin_plugin`
-- -----------------------------
INSERT INTO `dp_admin_plugin` VALUES ('1', 'SystemInfo', '系统环境信息', 'fa fa-fw fa-info-circle', '在后台首页显示服务器信息', '蔡伟明', 'http://www.caiweiming.com', '{\"display\":\"1\",\"width\":\"6\"}', '1.0.0', 'system_info.ming.plugin', '0', '1477757503', '1477757503', '100', '1');
INSERT INTO `dp_admin_plugin` VALUES ('2', 'DevTeam', '开发团队成员信息', 'fa fa-fw fa-users', '开发团队成员信息', '蔡伟明', 'http://www.caiweiming.com', '{\"display\":\"1\",\"width\":\"6\"}', '1.0.0', 'dev_team.ming.plugin', '0', '1477755780', '1477755780', '100', '1');

-- -----------------------------
-- Table structure for `dp_admin_role`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_role`;
CREATE TABLE `dp_admin_role` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '角色id',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上级角色',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '角色名称',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '角色描述',
  `menu_auth` text NOT NULL COMMENT '菜单权限',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `access` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否可登录后台',
  `default_module` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '默认访问模块',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='角色表';

-- -----------------------------
-- Records of `dp_admin_role`
-- -----------------------------
INSERT INTO `dp_admin_role` VALUES ('1', '0', '超级管理员', '系统默认创建的角色，拥有最高权限', '', '0', '1476270000', '1468117612', '1', '1', '0');

-- -----------------------------
-- Table structure for `dp_admin_user`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_user`;
CREATE TABLE `dp_admin_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL DEFAULT '' COMMENT '用户名',
  `nickname` varchar(32) NOT NULL DEFAULT '' COMMENT '昵称',
  `password` varchar(96) NOT NULL DEFAULT '' COMMENT '密码',
  `email` varchar(64) NOT NULL DEFAULT '' COMMENT '邮箱地址',
  `email_bind` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否绑定邮箱地址',
  `mobile` varchar(11) NOT NULL DEFAULT '' COMMENT '手机号码',
  `mobile_bind` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否绑定手机号码',
  `avatar` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '头像',
  `money` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '余额',
  `score` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '积分',
  `role` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '角色ID',
  `group` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '部门id',
  `signup_ip` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '注册ip',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `last_login_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '最后一次登录时间',
  `last_login_ip` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '登录ip',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态：0禁用，1启用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `dp_admin_user`
-- -----------------------------
INSERT INTO `dp_admin_user` VALUES ('1', 'admin', '超级管理员', '$2y$10$Brw6wmuSLIIx3Yabid8/Wu5l8VQ9M/H/CG3C9RqN9dUCwZW3ljGOK', '', '0', '', '0', '5', '0.00', '0', '1', '0', '0', '1476065410', '1590465605', '1590465605', '2130706433', '100', '1');

-- -----------------------------
-- Table structure for `dp_cms_advert`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_advert`;
CREATE TABLE `dp_cms_advert` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '分类id',
  `tagname` varchar(30) NOT NULL DEFAULT '' COMMENT '广告位标识',
  `ad_type` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '广告类型',
  `timeset` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '时间限制:0-永不过期,1-在设内时间内有效',
  `start_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '开始时间',
  `end_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '结束时间',
  `name` varchar(60) NOT NULL DEFAULT '' COMMENT '广告位名称',
  `content` text NOT NULL COMMENT '广告内容',
  `expcontent` text NOT NULL COMMENT '过期显示内容',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='广告表';


-- -----------------------------
-- Table structure for `dp_cms_advert_type`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_advert_type`;
CREATE TABLE `dp_cms_advert_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '分类名称',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='广告分类表';


-- -----------------------------
-- Table structure for `dp_cms_column`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_column`;
CREATE TABLE `dp_cms_column` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '父级id',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '栏目名称',
  `model` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '文档模型id',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '链接',
  `target` varchar(16) NOT NULL DEFAULT '_self' COMMENT '链接打开方式',
  `content` text NOT NULL COMMENT '内容',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '字体图标',
  `index_template` varchar(32) NOT NULL DEFAULT '' COMMENT '封面模板',
  `list_template` varchar(32) NOT NULL DEFAULT '' COMMENT '列表页模板',
  `detail_template` varchar(32) NOT NULL DEFAULT '' COMMENT '详情页模板',
  `post_auth` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '投稿权限',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `hide` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `rank_auth` int(11) NOT NULL DEFAULT '0' COMMENT '浏览权限，-1待审核，0为开放浏览，大于0则为对应的用户角色id',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '栏目属性：0-最终列表栏目，1-外部链接，2-频道封面',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='栏目表';


-- -----------------------------
-- Table structure for `dp_cms_document`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_document`;
CREATE TABLE `dp_cms_document` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '栏目id',
  `model` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '文档模型ID',
  `title` varchar(256) NOT NULL DEFAULT '' COMMENT '标题',
  `shorttitle` varchar(32) NOT NULL DEFAULT '' COMMENT '简略标题',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `flag` set('j','p','b','s','a','f','c','h') DEFAULT NULL COMMENT '自定义属性',
  `view` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '阅读量',
  `comment` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `good` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '点赞数',
  `bad` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '踩数',
  `mark` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数量',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `trash` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '回收站',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档基础表';


-- -----------------------------
-- Table structure for `dp_cms_field`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_field`;
CREATE TABLE `dp_cms_field` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '字段名称',
  `name` varchar(32) NOT NULL,
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '字段标题',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '字段类型',
  `define` varchar(128) NOT NULL DEFAULT '' COMMENT '字段定义',
  `value` text COMMENT '默认值',
  `options` text COMMENT '额外选项',
  `tips` varchar(256) NOT NULL DEFAULT '' COMMENT '提示说明',
  `fixed` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '是否为固定字段',
  `show` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '是否显示',
  `model` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '所属文档模型id',
  `ajax_url` varchar(256) NOT NULL DEFAULT '' COMMENT '联动下拉框ajax地址',
  `next_items` varchar(256) NOT NULL DEFAULT '' COMMENT '联动下拉框的下级下拉框名，多个以逗号隔开',
  `param` varchar(32) NOT NULL DEFAULT '' COMMENT '联动下拉框请求参数名',
  `format` varchar(32) NOT NULL DEFAULT '' COMMENT '格式，用于格式文本',
  `table` varchar(32) NOT NULL DEFAULT '' COMMENT '表名，只用于快速联动类型',
  `level` tinyint(2) unsigned NOT NULL DEFAULT '2' COMMENT '联动级别，只用于快速联动类型',
  `key` varchar(32) NOT NULL DEFAULT '' COMMENT '键字段，只用于快速联动类型',
  `option` varchar(32) NOT NULL DEFAULT '' COMMENT '值字段，只用于快速联动类型',
  `pid` varchar(32) NOT NULL DEFAULT '' COMMENT '父级id字段，只用于快速联动类型',
  `ak` varchar(32) NOT NULL DEFAULT '' COMMENT '百度地图appkey',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='文档字段表';

-- -----------------------------
-- Records of `dp_cms_field`
-- -----------------------------
INSERT INTO `dp_cms_field` VALUES ('1', 'id', 'ID', 'text', 'int(11) UNSIGNED NOT NULL', '0', '', 'ID', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480562978', '1480562978', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('2', 'cid', '栏目', 'select', 'int(11) UNSIGNED NOT NULL', '0', '', '请选择所属栏目', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480562978', '1480562978', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('3', 'uid', '用户ID', 'text', 'int(11) UNSIGNED NOT NULL', '0', '', '', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480563110', '1480563110', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('4', 'model', '模型ID', 'text', 'int(11) UNSIGNED NOT NULL', '0', '', '', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480563110', '1480563110', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('5', 'title', '标题', 'text', 'varchar(128) NOT NULL', '', '', '文档标题', '0', '1', '0', '', '', '', '', '', '0', '', '', '', '', '1480575844', '1480576134', '1', '1');
INSERT INTO `dp_cms_field` VALUES ('6', 'shorttitle', '简略标题', 'text', 'varchar(32) NOT NULL', '', '', '简略标题', '0', '1', '0', '', '', '', '', '', '0', '', '', '', '', '1480575844', '1480576134', '1', '1');
INSERT INTO `dp_cms_field` VALUES ('7', 'flag', '自定义属性', 'checkbox', 'set(\'j\',\'p\',\'b\',\'s\',\'a\',\'f\',\'h\',\'c\') NULL DEFAULT NULL', '', 'j:跳转\r\np:图片\r\nb:加粗\r\ns:滚动\r\na:特荐\r\nf:幻灯\r\nh:头条\r\nc:推荐', '自定义属性', '0', '1', '0', '', '', '', '', '', '0', '', '', '', '', '1480671258', '1480671258', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('8', 'view', '阅读量', 'text', 'int(11) UNSIGNED NOT NULL', '0', '', '', '0', '1', '0', '', '', '', '', '', '0', '', '', '', '', '1480563149', '1480563149', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('9', 'comment', '评论数', 'text', 'int(11) UNSIGNED NOT NULL', '0', '', '', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480563189', '1480563189', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('10', 'good', '点赞数', 'text', 'int(11) UNSIGNED NOT NULL', '0', '', '', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480563279', '1480563279', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('11', 'bad', '踩数', 'text', 'int(11) UNSIGNED NOT NULL', '0', '', '', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480563330', '1480563330', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('12', 'mark', '收藏数量', 'text', 'int(11) UNSIGNED NOT NULL', '0', '', '', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480563372', '1480563372', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('13', 'create_time', '创建时间', 'datetime', 'int(11) UNSIGNED NOT NULL', '0', '', '', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480563406', '1480563406', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('14', 'update_time', '更新时间', 'datetime', 'int(11) UNSIGNED NOT NULL', '0', '', '', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480563432', '1480563432', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('15', 'sort', '排序', 'text', 'int(11) NOT NULL', '100', '', '', '0', '1', '0', '', '', '', '', '', '0', '', '', '', '', '1480563510', '1480563510', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('16', 'status', '状态', 'radio', 'tinyint(2) UNSIGNED NOT NULL', '1', '0:禁用\r\n1:启用', '', '0', '1', '0', '', '', '', '', '', '0', '', '', '', '', '1480563576', '1480563576', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('17', 'trash', '回收站', 'text', 'tinyint(2) UNSIGNED NOT NULL', '0', '', '', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480563576', '1480563576', '100', '1');

-- -----------------------------
-- Table structure for `dp_cms_link`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_link`;
CREATE TABLE `dp_cms_link` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型：1-文字链接，2-图片链接',
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT '链接标题',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `logo` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '链接LOGO',
  `contact` varchar(255) NOT NULL DEFAULT '' COMMENT '联系方式',
  `sort` int(11) NOT NULL DEFAULT '100',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='有钱链接表';


-- -----------------------------
-- Table structure for `dp_cms_menu`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_menu`;
CREATE TABLE `dp_cms_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '导航id',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '父级id',
  `column` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '栏目id',
  `page` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '单页id',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '类型：0-栏目链接，1-单页链接，2-自定义链接',
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT '菜单标题',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '链接',
  `css` varchar(64) NOT NULL DEFAULT '' COMMENT 'css类',
  `rel` varchar(64) NOT NULL DEFAULT '' COMMENT '链接关系网',
  `target` varchar(16) NOT NULL DEFAULT '' COMMENT '打开方式',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='菜单表';

-- -----------------------------
-- Records of `dp_cms_menu`
-- -----------------------------
INSERT INTO `dp_cms_menu` VALUES ('1', '1', '0', '0', '0', '2', '首页', 'cms/index/index', '', '', '_self', '1492345605', '1492345605', '100', '1');
INSERT INTO `dp_cms_menu` VALUES ('2', '2', '0', '0', '0', '2', '关于我们', 'http://www.dolphinphp.com', '', '', '_self', '1492346763', '1492346763', '100', '1');
INSERT INTO `dp_cms_menu` VALUES ('3', '3', '0', '0', '0', '2', '开发文档', 'http://www.kancloud.cn/ming5112/dolphinphp', '', '', '_self', '1492346812', '1492346812', '100', '1');
INSERT INTO `dp_cms_menu` VALUES ('4', '3', '0', '0', '0', '2', '开发者社区', 'http://bbs.dolphinphp.com/', '', '', '_self', '1492346832', '1492346832', '100', '1');
INSERT INTO `dp_cms_menu` VALUES ('5', '1', '0', '0', '0', '2', '二级菜单', 'http://www.dolphinphp.com', '', '', '_self', '1492347372', '1492347510', '100', '1');
INSERT INTO `dp_cms_menu` VALUES ('6', '1', '5', '0', '0', '2', '子菜单', 'http://www.dolphinphp.com', '', '', '_self', '1492347388', '1492347520', '100', '1');

-- -----------------------------
-- Table structure for `dp_cms_model`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_model`;
CREATE TABLE `dp_cms_model` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '模型名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '模型标题',
  `table` varchar(64) NOT NULL DEFAULT '' COMMENT '附加表名称',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '模型类别：0-系统模型，1-普通模型，2-独立模型',
  `icon` varchar(64) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `system` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '是否系统模型',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='内容模型表';


-- -----------------------------
-- Table structure for `dp_cms_nav`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_nav`;
CREATE TABLE `dp_cms_nav` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tag` varchar(32) NOT NULL DEFAULT '' COMMENT '导航标识',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '菜单标题',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='导航表';

-- -----------------------------
-- Records of `dp_cms_nav`
-- -----------------------------
INSERT INTO `dp_cms_nav` VALUES ('1', 'main_nav', '顶部导航', '1492345083', '1492345083', '1');
INSERT INTO `dp_cms_nav` VALUES ('2', 'about_nav', '底部关于', '1492346685', '1492346685', '1');
INSERT INTO `dp_cms_nav` VALUES ('3', 'support_nav', '服务与支持', '1492346715', '1492346715', '1');

-- -----------------------------
-- Table structure for `dp_cms_page`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_page`;
CREATE TABLE `dp_cms_page` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL DEFAULT '' COMMENT '单页标题',
  `content` mediumtext NOT NULL COMMENT '单页内容',
  `keywords` varchar(32) NOT NULL DEFAULT '' COMMENT '关键词',
  `description` varchar(250) NOT NULL DEFAULT '' COMMENT '页面描述',
  `template` varchar(32) NOT NULL DEFAULT '' COMMENT '模板文件',
  `cover` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '单页封面',
  `view` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '阅读量',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='单页表';


-- -----------------------------
-- Table structure for `dp_cms_slider`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_slider`;
CREATE TABLE `dp_cms_slider` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '标题',
  `cover` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '封面id',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='滚动图片表';


-- -----------------------------
-- Table structure for `dp_cms_support`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_support`;
CREATE TABLE `dp_cms_support` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL DEFAULT '' COMMENT '客服名称',
  `qq` varchar(16) NOT NULL DEFAULT '' COMMENT 'QQ',
  `msn` varchar(100) NOT NULL DEFAULT '' COMMENT 'msn',
  `taobao` varchar(100) NOT NULL DEFAULT '' COMMENT 'taobao',
  `alibaba` varchar(100) NOT NULL DEFAULT '' COMMENT 'alibaba',
  `skype` varchar(100) NOT NULL DEFAULT '' COMMENT 'skype',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `sort` int(11) unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='客服表';


-- -----------------------------
-- Table structure for `dp_configuration`
-- -----------------------------
DROP TABLE IF EXISTS `dp_configuration`;
CREATE TABLE `dp_configuration` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键词',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `mobile` varchar(255) NOT NULL DEFAULT '' COMMENT '手机号码',
  `tel` varchar(50) NOT NULL DEFAULT '0' COMMENT '400号码',
  `icon` varchar(11) NOT NULL DEFAULT '0' COMMENT 'icon',
  `logo` varchar(255) NOT NULL COMMENT 'logo',
  `address` varchar(255) NOT NULL COMMENT '地址',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='公共配置表';

-- -----------------------------
-- Records of `dp_configuration`
-- -----------------------------
INSERT INTO `dp_configuration` VALUES ('1', '鹿角巷奶茶，奶茶加盟', '鹿角巷奶茶，奶茶加盟', '15528197997', '400-0388-517', '0', '8', '成都市青羊区顺城大街248号世界贸易中心Ａ座７楼', '0', '1590467883');

-- -----------------------------
-- Table structure for `dp_home_aboutus_message`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_aboutus_message`;
CREATE TABLE `dp_home_aboutus_message` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL DEFAULT '' COMMENT '姓名',
  `mobile` bigint(15) unsigned NOT NULL COMMENT '电话',
  `email` varchar(255) NOT NULL DEFAULT '' COMMENT '邮箱地址',
  `content` text NOT NULL COMMENT '消息内容',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `where_ip` bigint(20) unsigned NOT NULL COMMENT 'IP地址',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `read_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '阅读时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='消息表';

-- -----------------------------
-- Records of `dp_home_aboutus_message`
-- -----------------------------
INSERT INTO `dp_home_aboutus_message` VALUES ('1', '测试', '13219294337', '', '', '0', '0', '1590566839', '0');

-- -----------------------------
-- Table structure for `dp_home_news`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_news`;
CREATE TABLE `dp_home_news` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `img` varchar(255) NOT NULL COMMENT '封面图',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '标题',
  `desc` varchar(255) NOT NULL COMMENT '简介',
  `text` mediumtext NOT NULL COMMENT '文章内容',
  `time` varchar(255) NOT NULL DEFAULT '' COMMENT '显示时间',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='品牌动态';

-- -----------------------------
-- Records of `dp_home_news`
-- -----------------------------
INSERT INTO `dp_home_news` VALUES ('1', '65', '福建奶茶加盟_鹿角巷如何将利润增长与盈利空间成对比?', '随着餐饮市场上的多变发展，然要想在这激烈的市场中赚钱，在项目的选择就尤其重要，那福建奶茶加盟鹿角巷开店好吗?奶茶市场，消费者追去产品的新鲜感，有需求就有市场，鹿角巷打造多元素产品，对口输出，打造市场更具创新力品牌。', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">随着餐饮市场上的多变发展，然要想在这激烈的市场中赚钱，在项目的选择就尤其重要，那福建奶茶加盟鹿角巷开店好吗?奶茶市场，消费者追去产品的新鲜感，有需求就有市场，鹿角巷打造多元素产品，对口输出，打造市场更具创新力品牌。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">福建奶茶加盟鹿角巷开奶茶店的发展前景怎样?虽然市场品牌，鹿角巷作为一个具有潜力的奶茶品牌，良好市场口碑，打造独特的奶茶项目。鹿角巷奶茶在市场上，群众的实力奶茶项目，产品口碑上乘，开店利润也是相当高的。在激烈市场竞争当中，想要达到利润增长与盈利空间成为对比，需要怎么做?</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">作为一家门店，不会不想着盈利的上涨，加盟店想要看到利润有所增长，只有销售量增长了，那么就意味着盈利空间的增长.既然我们都是要想办法增加销量，那就要知道该从什么方向着手，要想销售量增长就需要在产品种类上想方法，产品种类增加了就会吸引更多的消费者。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷在整个茶饮市场势力不容小觑，打造市场优质的品牌，品牌具有相当实力。如今茶饮职业品牌众多，各品牌之间竞赛激烈，能跟鹿角巷奶茶这样的大品牌合作的话，创业路上一路像开挂一般，顺利无比。福建奶茶加盟鹿角巷开店能赚钱吗？鹿角巷奶茶一直坚持稳步发展，并没有短期内大量招商加盟的意思，后期顺应市场发展和消费者需求，也会逐步在更多地区开放加盟，有需要的朋友可以先提前申请，提前掌握商机。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷官网加盟，打造更好的市场口碑，增长市场利润，对于一个品牌来说，基础打造提高名气是相当重要的。福建奶茶加盟鹿角巷开店有什么优势？鹿角巷市场实力品牌，全国连锁效应，市场价值更大，价格更实惠!</p><p><br/></p>', '2020-1-10', '0', '1590545031', '1590545031', '1');
INSERT INTO `dp_home_news` VALUES ('2', '66', '河南奶茶加盟鹿角巷开奶茶店的发展钱景怎样?', '河南奶茶加盟哪家好?由于现在餐饮市场上竞争的激烈性,现在出门逛个街都随处可见商业街奶茶店的耸立,虽然有的茶饮店会挨着热门鹿角巷开店,但两家店确是截然不同。河南奶茶加盟鹿角巷开店的发展钱景怎样? ', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">河南奶茶加盟哪家好?由于现在餐饮市场上竞争的激烈性,现在出门逛个街都随处可见商业街奶茶店的耸立,虽然有的茶饮店会挨着热门鹿角巷开店,但两家店确是截然不同。河南奶茶加盟鹿角巷开店的发展钱景怎样?</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">奶茶市场多变发展，想要在激烈市场中赚钱，选择正确的项目，打造更好的市场发展空间。河南奶茶加盟鹿角巷开店怎样?鹿角巷奶茶品牌市场发展利润空间都是相当大的，高端品牌茶饮，在市场有更好的发展，以传承传统茶饮为己任，结合了新式茶饮的特色，创造出了自己独一无二的产品，得到了全国各地食客的忠心喜爱，它以特色的产品红遍了大江南北，在品牌开放加盟后，品牌得以更大程度上的推广，如今已经在茶饮行业无人能与之媲美。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">开鹿角巷奶茶店怎样?不管身处哪个行业，一定要了解清楚顾客的需求，并且加以满足，学会经营，门店生意才能越来越好。如果你想在河南开一家奶茶店，但又不懂得如何去分析顾客消费心理，也没有太多的资金，那可以选择加盟鹿角巷奶茶。在开业之前，总部就会提前对消费市场进行调查，从而分析出当地人们的消费习惯和需求。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">虽然市场竞争激烈，可还是有很多人选择鹿角巷奶茶进行加盟，这是值得深思的问题。顾客选择一家奶茶店并不仅仅在于奶茶的口味好，还有它便捷消费的属性，同时还有这家店面的文化内涵。在推销自家奶茶产品的时候，经营者不仅要着眼于产品本身，还有挖掘顾客更加深层次的消费理由和需求，分析清楚顾客需求是鹿角巷成功的原因。 河南奶茶加盟鹿角巷开奶茶店的发展钱景怎样?鹿角巷作为奶茶市场上有实力的品牌，能在市场脱颖而出，必定有其突出的发展优势，在细节下花足功夫，大到产品形象，小到菜单的设计等等，当然产品最重要!如果你对奶茶行业也感兴趣或对奶茶加盟有任何疑问都可在鹿角巷官网(www.lujiaoxiangzongbu.com)留言/留电咨询，我们会在第一时间联系并解惑！</p><p><br/></p>', '2019-12-15', '0', '1590545176', '1590545228', '1');
INSERT INTO `dp_home_news` VALUES ('3', '67', '鹿角巷奶茶值得加盟吗?鹿角巷加盟有保障吗?', '鹿角巷产品根据市场变化而进行相应升级迭代，品牌之所以能在茶饮排行榜上名列前茅，是与其推出的产品有密切的关系的。鹿角巷奶茶以极致奶茶美学为主打。', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">现在奶茶饮品的火爆让很多人都有想法要开一家奶茶店，我们发现，选择加盟<a href=\"http://www.lujiaoxiangzongbu.com/\" style=\"margin: 0px; padding: 0px; color: black; text-decoration-line: none;\">鹿角巷奶茶</a>，是个相当有前途的餐饮品类，鹿角巷奶茶加盟店已经开了很多家了，那么，鹿角巷奶茶值得加盟吗?鹿角巷奶茶加盟有保障吗?</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷产品根据市场变化而进行相应升级迭代，品牌之所以能在茶饮排行榜上名列前茅，是与其推出的产品有密切的关系的。鹿角巷奶茶以极致奶茶美学为主打，原料都是选用纯牛奶及进口茶叶，健康绿色。还有多款水果奶茶系列、水果鲜茶系列等多款经典奶茶。正因为鹿角巷奶茶品牌能够在产品上不断升级换代，才将自身的品牌价值毫无缺陷地建立起来。加盟鹿角巷奶茶，带你走上成功致富的道路!</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷是一个舒适清新的奶茶品牌，为了能够让顾客喝到好茶，鹿角巷尽力尝试了各种各样的口味，在各大节假日新品推陈出新，牢牢的抓住了消费者的胃，鹿角巷将设计与生活当作是一种体验，你可以从店铺的每个地方，都感受到鹿角巷对于生活和美的追求。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-size: 0px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><img src=\"/uploads/images/20200527/1d3cbcd7a65f641a09aaa53845d40f26.jpg\" title=\"nx5.jpg\" alt=\"\" width=\"48%;\"/> &nbsp; &nbsp;<img src=\"/uploads/images/20200527/3225144409b2713d401b04297da30ebd.jpg\" title=\"nx6.jpg\" alt=\"\" width=\"48%;\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">对于奶茶加盟商来说，总部为他们提供专业系统的服务，是他们选择加盟鹿角巷奶茶品牌的重要因素。鹿角巷以其周到的服务， 强大的品牌内涵闻名茶饮界，第一步，总部会为他们提供开业前的技术培训支持，包括免费技术培训、免费开业服务支持、免费技术研发支持等。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">随着这些加盟商的不断加入，鹿角巷在茶饮行榜上的地位也愈发得的牢不可破。鹿角巷总部管理系统完善，餐饮加盟品牌如果在管理上有所欠缺，肯定无法得到加盟商的认可。鹿角巷奶茶品牌正是意识到了这点的重要性，在这方面不遗余力的做出完善。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">首先鹿角巷奶茶品牌认真筛选每一个加盟商，力争将自己的团队打造成一个专业化的队伍。其次，鹿角巷奶茶总部实行统一的品牌形象，在店铺装修、培训、广告宣传上都严格执行标准流程。最后，鹿角巷奶茶总部有强大的资金支持和售后服务，为自身登上奶茶巅峰榜打下了坚实的基础！</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">加盟热线：400-0388-517</p><p><br/></p>', '2019-12-2', '0', '1590545368', '1590545494', '1');
INSERT INTO `dp_home_news` VALUES ('4', '65', '一杯以美学定义的奶茶---鹿角巷', '鹿角巷深信，茶饮，喝的是一份感触，品的是一份美好，鹿角巷将设计与生活当作是一种体验，你可以从店铺的每个地方，都感受到鹿角巷对于生活和美的追求。', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">“创业的目的并不是为了改变世界，当时只想做点副业。做老师和设计都属于饿不死，但赚不到什么钱的工作。”邱茂庭说。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷最初在台湾成立，现目前公司分别在越南、加拿大、澳门、香港、马来西亚、日本等国家和地区开设门店，2018年初鹿角巷奶茶第一站在上海打响，同年开始进军内地茶饮市场。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷是一个舒适清新的奶茶品牌，为了能够让顾客喝到好茶，鹿角巷尽力尝试了各种各样的口味，在各大节假日新品推陈出新，牢牢的抓住了消费者的胃，鹿角巷将设计与生活当作是一种体验，你可以从店铺的每个地方，都感受到鹿角巷对于生活和美的追求。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">在The Alley里坐着交谈，放空烦恼，清闲舒服的为自己来杯下午茶，沉醉在像春日般的梦境，说不上的惬意，It&#39;s time for tea !</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-size: 0px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><img src=\"/uploads/images/20200527/3659cb979d2373fab425e38f4fc14e41.jpg\" title=\"nx3.jpg\" alt=\"\" width=\"48%\"/> &nbsp; &nbsp;<img src=\"/uploads/images/20200527/7c544ce4836e1c776c50df27504046e7.jpg\" title=\"nx4.jpg\" alt=\"\" width=\"48%\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷深信，茶饮，喝的是一份感触，品的是一份美好，鹿角巷奶茶希望将那些藏在你我心底，难以形容却令人神往的舒适，透过The Alley的饮品，再度勾勒出一个美好生活应有的样貌。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷成功打造的创意美学，体现在它的每一款产品当中，比如鹿角巷的招牌奶茶鹿丸鲜奶，就称得上是奶茶界中的“泥石流”，鹿角巷的杯子不是普通大众的奶茶杯，使用了底部为圆弧状、杯身从视觉上看来相对“矮胖”的新杯型，俗称“胖胖杯”。颜控的人一定先是被胖胖杯吸粉的！胖胖杯在“虎皮纹”的衬托显得更为可爱。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">加盟热线：400-0388-517</p><p><br/></p>', '2019-12-1', '0', '1590545580', '1590545694', '1');
INSERT INTO `dp_home_news` VALUES ('5', '72', '冬天适合开奶茶店吗?', '奶茶可以说是现在人气最高的网红饮品，出门逛街，奶茶也几乎是人们必买的饮品，可能很多人会说奶茶是一个季节性严重的行业，夏天是这个行业的旺季，到了冬天都很难经营，但是现实真的如此吗？', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">要地位。可能很多人会说奶茶是一个季节性严重的行业，夏天是这个行业的旺季，到了冬天都很难经营，但是现实真的如此吗？冬天适合开奶茶店吗？</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">奶茶作为我国饮品行业中发展速度最快的一个行业，庞大的市场正在吸引着众多的创业者加入其中。奶茶品牌也是层出不穷，从整个商业角度来看如今的奶茶市场正处于群雄并起的时代，庞大的市场消费支撑起了众多的奶茶创业者。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">很多刚进入奶茶行业的创业者心中都会有这样一个疑问“冬天适合开奶茶店吗？”，这个问题我们可以从目前的奶茶市场去寻找答案。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-size: 0px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><img src=\"/uploads/images/20200527/c97db65442ea45fc4afb3c84f381df14.jpg\" title=\"nx1.jpg\" alt=\"\" width=\"48%\"/> &nbsp; &nbsp;<img src=\"/uploads/images/20200527/a03f6a7d8dbe399cec1ec009257e5388.jpg\" title=\"nx2.jpg\" alt=\"\" width=\"48%\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">奶茶从最初只售卖冷饮到现在经过多年的多元化发展，品类早就发生了翻天覆地的变化，可以满足消费者的所有需求，冬天人手一杯暖心暖胃的奶茶早已成了普遍的现象，这个现象自然也就解答了“冬天适合开奶茶店吗”这个问题！优胜劣汰正在奶茶行业中上演，激烈的市场竞争也正说明了奶茶行业正处于“洗牌”的状态，最终在不断的大浪淘沙之下，好的奶茶品牌自然会逐渐显露！</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">不论是夏天还是冬天，都是适合开奶茶店的，从这一点而言，奶茶行业的确算得上是一个不错的投资项目。但是如今奶茶市场“前浪推后浪”的现象屡见不鲜，众多奶茶品牌也在尝试寻找突破之路。各位准备入行奶茶行业的创业者自身还得做好充足的准备，未雨绸缪才能保证创业者在之后的奶茶经营中有及时应对的准备！</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">加盟热线：400-0388-517</p><p><br/></p>', '2019-11-30', '0', '1590545831', '1590545831', '1');
INSERT INTO `dp_home_news` VALUES ('6', '75', '小本投资项目如何选择，鹿角巷奶茶备受关注', '茶饮市场是目前比较火爆的一个餐饮品类，鹿角巷就是一个比较吸引人的茶饮品牌，而且这样的好品牌当然是比较容易吸引消费者的，未来的发展前景当然也会比较广阔。', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">如今这个社会，人人都在创业，那么小本投资到底该如何选择项目了?<a href=\"http://www.lujiaoxiangzongbu.com/\" style=\"margin: 0px; padding: 0px; color: black; text-decoration-line: none;\">奶茶</a>因为独特的口感，在我国餐饮市场上特别受欢迎，很多的创业者都被其中的商机和利润所吸引，想要加入到这个行业当中来开始自己的创业之路。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">茶饮市场是目前比较火爆的一个餐饮品类，鹿角巷就是一个比较吸引人的茶饮品牌，而且这样的好品牌当然是比较容易吸引消费者的，未来的发展前景当然也会比较广阔</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷投资费用不是很高，具体投资费用由加盟区域及店面大小决定，在大部分投资者能够接受的范围之内，鹿角巷作为茶饮行业的佼佼者，加盟价值是比较大的。鹿角巷适合大众创业，小本投资，回报快，在加盟之后能够得到总部免费培训服务，还有专业人员提供选址帮助，让加盟者减少更多后顾之忧，使加盟风险降到最低，不需要因为客源问题而发愁。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-size: 0px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><img src=\"/uploads/images/20200527/b46388ee854b2000b4d2a7f92019b30c.jpg\" title=\"nx11.jpg\" alt=\"\" width=\"48%\"/> &nbsp; &nbsp;<img src=\"/uploads/images/20200527/cb857dc94ef291d590ad8974a1b8bfe8.jpg\" title=\"nx12.jpg\" alt=\"\" width=\"48%\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷拥有专业的评估选址团队，十余年选址经验大咖，给加盟商提供切实可行的店铺选址建议，让加盟商在开店之初就快人一步。鹿角巷拥有专业的设计团队，为加盟商量身打造装修设计方案，独家打造装修设计效果图，让加盟商时时刻刻体会到公司的全程服务。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷拥有完备的供应链体系，全国各大区配备物流渠道，确保原料的及时配送，为开店做好充足的准备，解除加盟商的后顾之忧。总部拥有专业的品牌营销团队，整合各行业渠道优质资源，为加盟商定制线上线下全方位的营销策划服务，并为加盟商建立社群体系，让加盟商拥有更多的客户资源。选择鹿角巷，你就离成功更近一步！</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">加盟热线：400-0388-517</p><p><br/></p>', '2019-11-29', '0', '1590546062', '1590546062', '1');
INSERT INTO `dp_home_news` VALUES ('7', '79', '鹿角巷奶茶，总有一款是你的菜', '来自台湾本土的鹿角巷奶茶，自2018年初进军内地以来，其势头就从未停歇过，风潮不断，锐头不减，鹿角巷店铺也成为年轻男女的打卡圣地。奶茶中的“泥石流”称号实至名归！', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">随着生活品质的提高，人们对于美食和各种饮品的追求也不断刷新。休闲时间，点一杯奶茶似乎已成为了常态，在如今茶饮市场泛滥的时候，你会不会有独自钟爱的一款了？</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">来自台湾本土的鹿角巷奶茶，自2018年初进军内地以来，其势头就从未停歇过，风潮不断，锐头不减，鹿角巷店铺也成为年轻男女的打卡圣地。奶茶中的“泥石流”称号实至名归！</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷注重美学与产品的统一，店铺风格则体现出一种极致的美感。鹿角巷创始人邱茂庭，本身作为台湾著名插画师，他将艺术美学融入鹿角巷的每一款产品当中，富予奶茶以形象，让喝过鹿角巷奶茶的每一位食客都能记住它的味道。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-size: 0px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><img src=\"/uploads/images/20200527/2be1b56965a90a1aa15da728d313694d.jpg\" title=\"nx9.jpg\" alt=\"\" width=\"48%;\"/> &nbsp; &nbsp;<img src=\"/uploads/images/20200527/d2a69083f3aa9062da978b80722c0274.jpg\" title=\"nx10.jpg\" alt=\"\" width=\"48%;\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷会在每个节假日推出限时新品，节日周边，使得鹿角巷的品牌形象深入人心。18年圣诞推出圣诞新草杯，香气纯粹的焙茶制作成冰沙，奶油像云朵一样落在杯顶，撒上了香醇的核桃和曲奇，插上了小鹿角和小鹿红鼻子造型的巧克力，节日感十足！一经推出，便被抢购一空。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷对于品质的坚持是它成长的源动力。每一杯都要做到精益求精，追求完美，鹿丸鲜奶中采用的鹿丸为当天现熬六小时以上，鲜奶采用产业链直供，从源头做到保障，鹿角巷的坚持为品牌赢得了众多的食客，我们亲切的称呼他们为“鹿粉”。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">加盟热线：400-0388-517</p><p><br/></p>', '2019-11-28', '0', '1590546285', '1590546285', '1');
INSERT INTO `dp_home_news` VALUES ('8', '66', '带你走近“2019茶饮十大品牌”之一的鹿角巷', '冬休闲茶饮市场的消费者已经从最开始的奶茶配料时代，走向品质时代。市场上目前火爆的餐饮品牌都是以茶为主打产品。茶好喝，一定是推品质。', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">2018年底到2019年初来自台湾的一大奶茶品牌鹿角巷广受消费者欢迎，那么鹿角巷为什么这么火，与众多茶饮品牌又有什么区别吗？让我们一起走近“2019<a href=\"http://www.lujiaoxiangzongbu.com/\" style=\"margin: 0px; padding: 0px; color: black; text-decoration-line: none;\">茶饮十大品牌</a>”之一的鹿角巷，看看鹿角巷是如何一步步做到如今的成绩的。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷作为台湾本土特色餐饮，早在18年便开始进军国内市场，鹿角巷不仅仅追求单品、爆款，其主打的茶饮和品牌周边也都非常受到市场的欢迎。目前，鹿角巷开发了30多款口味的茶饮，其招牌奶茶鹿丸鲜奶更是大受消费者欢迎。作为鹿角巷的主打产品之一，鹿角巷每一杯奶茶制作流程都十分考究，鲜奶采用产业链直供，从鲜奶源头做到品质保障，其中的鹿丸也是当天现熬6小时以上。精益求精便是鹿角巷带给消费者的绝对实力</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷对于海外市场也绝不放过，目前鹿角巷在全世界38个国家设有直营店铺，消费人群覆盖全球百分之八十以上。 作为奶茶行业中的“泥石流”品牌，鹿角巷真正做到了从国内走出去的企愿。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-size: 0px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><img src=\"/uploads/images/20200527/2be1b56965a90a1aa15da728d313694d.jpg\" title=\"nx9.jpg\" alt=\"\" width=\"48%;\"/><img src=\"/uploads/images/20200527/d2a69083f3aa9062da978b80722c0274.jpg\" title=\"nx10.jpg\" alt=\"\" width=\"48%;\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">我们可以看到鹿角巷如今取得的成绩，不是偶然。“我们不是突然就火起来的，这是时间积累起来的。”邱茂庭认为，休闲茶饮市场的消费者已经从最开始的奶茶配料时代，走向品质时代。市场上目前火爆的餐饮品牌都是以茶为主打产品。茶好喝，一定是推品质。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">选择加盟项目，我们不能忽视的就是优势，有了优势才能有强大的竞争力，如果品牌没有优势，那么加盟就没有可靠。鹿角巷的大名相信大家早有耳闻，它在全国的加盟店突破千家，在市场上有绝对高的知名度和口碑，当是你创业加盟的绝佳选择！</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">加盟热线：400-0388-517</p><p><br/></p>', '2019-11-27', '0', '1590546395', '1590546462', '1');
INSERT INTO `dp_home_news` VALUES ('9', '81', '带你了解2019年茶饮十大品牌之一的鹿角巷', '鹿角巷的大名相信大家早有耳闻，它在全国的加盟店突破千家，强大的品牌竞争力助力，进军国际茶饮市场，在市场上有绝对高的知名度和口碑。', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">选择<a href=\"http://www.lujiaoxiangzongbu.com/\" style=\"margin: 0px; padding: 0px; color: black; text-decoration-line: none;\">加盟</a>项目，我们不能忽视的就是优势，有了优势才能有强大的竞争力，如果品牌没有优势，那么加盟就没有可靠。鹿角巷的大名相信大家早有耳闻，它在全国的加盟店突破千家，在市场上有绝对高的知名度和口碑</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">那么鹿角巷加盟前景如何？加盟有什么优势？多重优势助力拓宽业绩。接下来，就是鹿角巷项目的诸多优势隆重出场的时刻了。自2013年成立起，多年来极速发展，已经是中国茶饮十大代表性品牌。在全国各地都可以看到它的身影，加盟店众多。毫无疑问鹿角巷的市场前景十分广阔，加盟优势突出，店铺利润大，是不可多得的加盟品牌。我们从它众多优势中慢慢抽丝剥茧，一一分析下吧。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">首先映入眼帘的就是利润优势，鹿角巷以精致美学、追求极致等特色立足在市场中，一经上市就得到了消费者喜爱，店店火爆绝不是夸张。这样的销售量就预示着鹿角巷加盟前景的广阔，利润优势在整个餐饮业都是首屈一指的。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-size: 0px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><img src=\"/uploads/images/20200527/2ceb6cee663bad9956691a54e7ba5a39.jpg\" title=\"nx7.jpg\" alt=\"\" width=\"48%;\"/> &nbsp;<img src=\"/uploads/images/20200527/e7bb9b5a45cd89ba3a8c5ee383465103.jpg\" title=\"nx8.jpg\" alt=\"\" width=\"48%;\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">加盟鹿角巷你也不用担心宣传，因为总部的宣传优势也是让人大为惊叹的。鹿角巷拥有经验丰富的策划团队，总部定期组织明星到店活动，制定合适方式进行宣传，扩大鹿角巷的影响力和知名度，然后在不同的季节、不同的节日中还会推出相应的一系列促销活动，大大增强消费者的互动。一个品牌，如果能够和消费者保持良好的互动关系，接下来粘性关联就会变得非常牢固。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">无论你现在做什么，谁不想让自己的事业可以变得非常出彩呢？加盟鹿角巷，给你创业成功的资本，让你凭借鹿角巷的种种优势，在餐饮界如鱼得水。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">加盟热线：400-0388-517</p><p><br/></p>', '2019-11-26', '0', '1590546669', '1590546669', '1');
INSERT INTO `dp_home_news` VALUES ('10', '84', '鹿角巷奶茶怎么样？为何它有这么多人投资', '冬天一来，大家就纷纷的都往饮品店里面跑了。鹿角巷奶茶店外面更是排起了长龙。想要发家致富，茶饮行业便是一个不错的选择。', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">冬天一来，大家就纷纷的都往饮品店里面跑了。<a href=\"http://www.lujiaoxiangzongbu.com/\" style=\"margin: 0px; padding: 0px; color: black; text-decoration-line: none;\">鹿角巷奶茶</a>鹿 角巷奶茶店外面更是排起了长龙。想要发家致富，茶饮行业便是一个不错的选择。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷奶茶怎么样？为何它有这么多人投资开店了？我想正是因为鹿角巷对于加盟商的支持服务力度，因此，大家都想要加盟进来。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷拥有着阵容强大的营运团队，在经过多年的店铺管理经验，鹿角巷已经拥有自己成熟的店铺运营管理团队，技术已经是相当成熟。通过总部、分部的协助，将系统的运运营模式运用到每一家奶茶店铺中去，来提升店铺的运营技巧。鹿角巷拥有多元要素的营销策略，综合了地区资源以及发挥异业合作，向全国加盟店推出营销活动来提高品牌的知名度，来获得更多消费者的认可与喜爱。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-size: 0px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><img src=\"/uploads/images/20200527/2ceb6cee663bad9956691a54e7ba5a39.jpg\" title=\"nx7.jpg\" alt=\"\" width=\"48%;\"/> &nbsp;<img src=\"/uploads/images/20200527/e7bb9b5a45cd89ba3a8c5ee383465103.jpg\" title=\"nx8.jpg\" alt=\"\" width=\"48%;\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷拥有完善实用的物流规划，总部会合理规划各个地域的物流仓储系统，将由总公司与区域经理合心协作，为加盟商进行物料的配送，在这方面也将进行对便捷性、准确性、安全性等进行考察。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷拥有总部专业人员研发，依据创新或是健康的食材、季节差异以及营销活动进行新品的推出。标准规范的开发资源，鹿角巷总部设有专门的开发资源部，将协助加盟商进行店铺的选址与评估，以附近资源力量来进行投资可行的详细计算，来获得正确的店铺位置。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">不知你是否被这个优势多多的项目吸引过来了呢？其实现在就有很多的投资人想要加入，你是其中的一个吗？</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">加盟热线：400-0388-517</p><p><br/></p>', '2019-11-25', '0', '1590546816', '1590546850', '1');
INSERT INTO `dp_home_news` VALUES ('11', '85', '鹿角巷奶茶店是你最理想的开店选择', '鹿角巷总部为了扩大市场占有率，不断进行品牌的宣传与推广，推出“一日店长”活动，吸粉无数！极大的提升了品牌知名度。', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><a href=\"http://www.lujiaoxiangzongbu.com/\" style=\"margin: 0px; padding: 0px; color: black; text-decoration-line: none;\">鹿角巷</a>&nbsp;随着越来越多人对奶茶的认可和喜爱，奶茶行业的发展前景也被越来越多人看好，奶茶店加盟成为很多人投资的首选项目。对奶茶行业有所了解的人都知道，休闲奶茶的消费者群体非常广泛，想要开个赚钱的奶茶加盟店，就得选择一个知名度大的加盟品牌，鹿角巷奶茶便是最理想的一个选择。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">作为奶茶行业中的“泥石流”品牌，鹿角巷不仅拥有着非常高的知名度，而且市场口碑也非常好。特别是在年轻的消费群体中，鹿角巷就是时尚美味的标志。在这样行业有着广泛的知名度，良好的消费者口碑，大大提升了鹿角巷的品牌影响力</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷旗下产品种类丰富，主要有招牌奶茶黑糖鹿丸鲜奶、、鹿丸噗哩系列、特色饮品北极光，晨曦等一系列品种，不仅产品种类繁多，而且口感独特丰富，满足不同消费者的不同追求。同时不断研发培训新品，量身打造出很多特色鲜明的新品，受到广大消费者们的热爱和追捧。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-size: 0px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><img src=\"/uploads/images/20200527/1d3cbcd7a65f641a09aaa53845d40f26.jpg\" title=\"nx5.jpg\" alt=\"\" width=\"48%;\"/> &nbsp; &nbsp;<img src=\"/uploads/images/20200527/3225144409b2713d401b04297da30ebd.jpg\" title=\"nx6.jpg\" alt=\"\" width=\"48%;\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷总部为了扩大市场占有率，不断进行品牌的宣传与推广，推出“一日店长”活动，吸粉无数！极大的提升了品牌知名度。为了吸引消费者建立良好评价，不断进行新品的开发，满足众多消费者不断变化的需求，受到了诸多消费者的一致称赞。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">对于相信鹿角巷的投资者，总部提供全方位的开店协助，除了筹备期间的各类协助之外，还免费提供专业的经营管理培训。为了帮助加盟商更好的开店，鹿角巷不断提升并完善服务，让所有加盟商都能轻轻松松创业开店，鹿角巷的市场占有率也会不断扩大，让更多人知道鹿角巷的存在！</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">加盟热线：400-0388-517</p><p><br/></p>', '2019-11-24', '0', '1590546984', '1590557356', '1');
INSERT INTO `dp_home_news` VALUES ('12', '86', '专业化流程，标准化制作，铸就鹿角巷极致品质！', '鹿角巷鲜明的品牌形象，良好的口碑，优秀的管理团队，多年的行业经验，5年多的店面管理经验，强大的技术团队，巨大的无形资产，在广大的顾客心中生根发芽。', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><a href=\"http://www.lujiaoxiangzongbu.com/\" style=\"margin: 0px; padding: 0px; color: black; text-decoration-line: none;\">鹿角巷</a>&nbsp;鲜明的品牌形象，良好的口碑，优秀的管理团队，多年的行业经验，5年多的店面管理经验，强大的技术团队，巨大的无形资产，在广大的顾客心中生根发芽，口碑是鹿角巷宝贵的无形资产。区域保障，确保约定区域自家经营。鹿角巷强大的后续服务支持，质量稳定、可靠的产品和服务</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">超低的投资风险严格的成本控制体系建立在专业研发、工厂化生产和统一操作的基础上、鹿角巷实力雄厚，完全具备以上条件，使每一位加盟者的投资风险降到“0”。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">快速的出品速度鹿角巷的制作保证了每家加盟店都能够以快的速度出品，无需客户等待，更增加了单店的营业额。鹿角巷的产品从包装到色彩都精致耐看，让人赏心悦目；每一份产品都经过精心调配，达到营养平衡；产品味道更堪称经典，令人回味无穷。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-size: 0px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><img src=\"/uploads/images/20200527/3659cb979d2373fab425e38f4fc14e41.jpg\" title=\"nx3.jpg\" alt=\"\" width=\"48%\"/> &nbsp; &nbsp;<img src=\"/uploads/images/20200527/7c544ce4836e1c776c50df27504046e7.jpg\" title=\"nx4.jpg\" alt=\"\" width=\"48%\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">不断推陈出新顾客对美味追求的日益改变，造就了鹿角巷满足顾客口味的诚意。鹿角巷奶茶新品研发能力，让新品层出不穷，为各加盟店源源不断推出新产品提供有力保证。简便的经营模式您只需提供自己的资金实力情况，其余的事情就放心的交给鹿角巷吧！从店面选址，装修策划，促销方案，所有的运营方略已经为您准备就绪。优质的原材料供应，严格的检验，生产安全的高质的产品是鹿角巷对顾客和加盟者的承诺。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">让顾客享受美味的同时更加安全放心是鹿角巷的追求。设备质量和价格是我们历来注重的。简洁明亮的鹿角巷店面，结合现代装修美学简洁大方的特点，店内宽敞明亮，舒适优雅。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">丰富的产品种类，使鹿角巷含盖市面上众多的受众人群。如此多的产品无一不是经过专业人员潜心研制的。目的在于使顾客满足口腹之欲的同时又能给予身体全面的营养素，以满足各年龄层顾客对美味、营养的双追求。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">加盟热线：400-0388-517</p><p><br/></p>', '2019-11-23', '0', '1590557528', '1590557623', '1');
INSERT INTO `dp_home_news` VALUES ('13', '87', '鹿角巷作为奶茶“泥石流”的品牌实力', '鹿角巷专注做一杯健康好茶，每一杯采用优选原料，层层把关。鹿角巷精选台湾高山好茶，精心选材，健康搭配，是时下最受追捧的热销奶茶之一。', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷专注<a href=\"http://www.lujiaoxiangzongbu.com/\" style=\"margin: 0px; padding: 0px; color: black; text-decoration-line: none;\">奶茶</a>高端饮品，也是国内饮品模式的知名品牌。作为颠覆 性健康街饮食高端知名品牌，鹿角巷沿袭了业内国际巨头一贯的时尚、 安全、健康和高品质的血脉，店内形象时尚精致，产品严格按照业内较 高的安全标准现场制作，是时下最受追捧的热销奶茶之一。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷专注做一杯健康好茶，采用优选原料，层层把关。鹿角巷精选台湾高 山好茶，精心选材，健康搭配。为确保口感的同时，更注重健康。每一滴水 都通过深层洁净，新鲜泡好茶、拒绝使用茶粉茶包，越喝越健康。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">优质品质在于不断研发。鹿角巷奶茶加盟店设定了多款系列产品，近50款品 牌周边，打造四季火热的贴心奶茶店。鹿角巷奶茶秉承“新鲜，健康，品质” 的理念，结合时令选取新鲜水果，不断推出新品，为消费者提供一年四季都 触手可及的美味饮品。无论是鲜榨果汁还是清新茶饮，这里都一应俱全。鹿 角巷在用心做饮品，口味不断升级，带给消费者超享受体验。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-size: 0px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><img src=\"/uploads/images/20200527/c97db65442ea45fc4afb3c84f381df14.jpg\" title=\"nx1.jpg\" alt=\"\" width=\"48%\"/> &nbsp; &nbsp;<img src=\"/uploads/images/20200527/a03f6a7d8dbe399cec1ec009257e5388.jpg\" title=\"nx2.jpg\" alt=\"\" width=\"48%\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">一条龙全程扶持。鹿角巷奶茶加盟总部为创业者供给选址、装修、训练、技 能等方面的支撑，除此之外，在门店运营、原材料配送方面，总部也会提供 多方位支持。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷采用标准化制作，千店如一。鹿角巷奶茶在时刻把握顾客对茶饮时尚追 求的同时，不断引进奶茶技术以及先进设备、不同口味，适合年轻时尚消费 者的新饮品;同时透过标准化的程序设定，让茶饮品质更易控管，做出真正健 康绿色的时尚饮品。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">加盟热线：400-0388-517</p><p><br/></p>', '2019-11-22', '0', '1590557709', '1590557798', '1');
INSERT INTO `dp_home_news` VALUES ('14', '88', '寒意来袭，来一杯鹿角巷奶茶给你最惬意的享受', '鹿角巷的奶茶饮品不仅款款颜值爆表，刷屏网红扛把子！而且，还有多款系列，风味各异，每一款都足以让你感叹鹿角巷的魅力所在！', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">如今<a href=\"http://www.lujiaoxiangzongbu.com/\" style=\"margin: 0px; padding: 0px; color: black; text-decoration-line: none;\">奶茶</a>的口味种类 越来越多，今天给大家推荐的是奶茶界的一匹黑马——鹿角巷奶茶！</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷家奶茶以其高颜值的外表，一经推出，便独领奶茶界风骚。鹿角巷奶茶的味道香浓 ，鹿角巷终坚持现制饮品的理念，所用鹿丸全部当天现熬，保证品质的上乘和味道的统一 ，所有茶饮全部现场纯手工制作，坚持绝不添加防腐剂和人工添加剂，只为让你享受到新 鲜、真实、细腻的健康味道。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷为了能让每一杯奶茶都还原正宗的味道，跋涉千里寻好茶，再采用高压冲击，释放 茶的香味，让口感更加富丽。用好茶、好果、好冰结合成一杯好茶饮，正适合广大消费者 的饮用口味，在市场上得到了很多消费者的认可。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-size: 0px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><img src=\"/uploads/images/20200527/b46388ee854b2000b4d2a7f92019b30c.jpg\" title=\"nx11.jpg\" alt=\"\" width=\"48%\"/> &nbsp; &nbsp;<img src=\"/uploads/images/20200527/cb857dc94ef291d590ad8974a1b8bfe8.jpg\" title=\"nx12.jpg\" alt=\"\" width=\"48%\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷的奶茶饮品不仅款款颜值爆表，刷屏网红扛把子！而且，还有多款系列，风味各异， 每一款都足以让你感叹鹿角巷的魅力所在！无论是逛街、看电影，还是朋友小聚，点一杯 鹿丸鲜奶，让奶香跟舌头一起翻滚，惬意到不行~你不来一杯嘛？</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">现在想开店，选择好的投资行业至关重要，鹿角巷奶茶投资很小，而且鹿角巷奶茶奢华的美 食洗礼，使大家心情愉悦。商家选择它，自然就可以获得多款产品支持，所以这样的奶茶项 目是创业的绝佳选择。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷奶茶坚持为人们打造绿色健康的奶茶饮品，美味，大家可以放心喝，刚推出便掀起了火 热的市场。开鹿角巷奶茶加盟店仅需万元，成本少，风险小。经过短短几年的发展，如今鹿角 巷奶茶的加盟店就已经遍及全球各地，品牌知名度不断提升，是奶茶加盟的最具潜力品牌。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">加盟热线：400-0388-517</p><p><br/></p>', '2019-11-21', '0', '1590557859', '1590558015', '1');
INSERT INTO `dp_home_news` VALUES ('15', '89', '茶饮项目如何选择?鹿角巷奶茶备受青睐', '饮品行业发展迅速，很多创业人对这个行业蠢蠢欲动，那么茶饮项目如何选择?就成为了很多人想了解清楚的问题。', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><a href=\"http://www.lujiaoxiangzongbu.com/\" style=\"margin: 0px; padding: 0px; color: black; text-decoration-line: none;\">奶茶</a>饮品行业 发展迅速，很多创业人对这个行业蠢蠢欲动，那么茶饮项目如何选择?就成为了 很多人想了解清楚的问题。同行不同利，想要成功选择鹿角巷奶茶是明智的，这 是一个可以展现自身能力，成就致富梦想的好项目。消费者的认可，总部的不断 创新完善，是你成就一番事业的关键筹码。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷好评不断客源丰富，鹿角巷奶茶有超高的人气，更有良好的口碑，吸引了很 多创业人的争相加盟，鹿角巷奶茶是一个利润不错的项目，投资不大，它选择台 湾正宗黑糖加工制作，制作出来的鹿角巷特色鹿丸满足了各界吃货的味蕾，未来拥 有更大的发展空间，可见与实力品牌合作的重要性，你心动了吗?</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-size: 0px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><img src=\"/uploads/images/20200527/2be1b56965a90a1aa15da728d313694d.jpg\" title=\"nx9.jpg\" alt=\"\" width=\"48%;\"/> &nbsp; &nbsp;<img src=\"/uploads/images/20200527/d2a69083f3aa9062da978b80722c0274.jpg\" title=\"nx10.jpg\" alt=\"\" width=\"48%;\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷奶茶经过发展已经成为了行业当中的翘楚，在很多城市都能看到其品牌的身影 ，红火的经营场景是对产品的认可，也是品牌实力的彰显。鹿角巷奶茶其总部有着成 熟的运营理念，还有很多的成功案例能够为创业者保驾护航。 总部实力强大扶持到位。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷奶茶拥有多种口味，根据季节变化，市场需求会不断更新产品，其核心口味的鹿 丸鲜奶更是赢得了广大消费者的热烈追捧！也是确保鹿角巷奶茶项目独占市场的绝密武 器，同时多元化的产品组合都让食客有新鲜感，另外公司技术团队会根据地方口味的有 所不同进行口味微调，鹿角巷奶茶加盟让您的经营灵活自如。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷奶茶是不会让您失望的，它是一个创业者争相加盟的好项目，其总部还有很多的 扶持政策，可以为创业者提供保障，哪怕您是一个创业新手也可以无忧创业。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">加盟热线：400-0388-517</p><p><br/></p>', '2019-11-20', '0', '1590558129', '1590558172', '1');
INSERT INTO `dp_home_news` VALUES ('16', '67', '优雅精致的鹿角巷奶茶店是你休憩时光的绝佳去处', '鹿角巷奶茶在时刻了解消费者的需求变化，品牌的理念发展时刻贴合消费者的需求，在奶茶市场上占据举足轻重的地位', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">现代人的时间是很宝贵的，年轻人的时间都是<a href=\"http://www.lujiaoxiangzongbu.com/\" style=\"margin: 0px; padding: 0px; color: black; text-decoration-line: none;\">奶茶</a>的 ！奶茶如今是占据人 们内心最大份额的休闲时尚饮品，当下我们这些年轻小伙伴的生活中已经 基本上离不开奶茶这个饮品的存在了。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">不管是休闲娱乐，还是逛街聚会，奶茶都是成为人们最好的伴侣。一杯奶茶为我带来的，并不是单 纯的一杯美味饮品那么简单，更多的是一种情怀的寄托，以及对忙碌的工作节奏和生活压力的一个 放松的方式。而来鹿角巷奶茶就带给了我享受片刻静谧休闲时光的机会。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-size: 0px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><img src=\"/uploads/images/20200527/2ceb6cee663bad9956691a54e7ba5a39.jpg\" title=\"nx7.jpg\" alt=\"\" width=\"48%;\"/> &nbsp;<img src=\"/uploads/images/20200527/e7bb9b5a45cd89ba3a8c5ee383465103.jpg\" title=\"nx8.jpg\" alt=\"\" width=\"48%;\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷奶茶在时刻了解消费者的需求变化，品牌的理念发展更加贴合消费者的需求，能够享受到的是 美味的奶茶，还有其店铺舒适优美的环境，在这样的环境中享受一杯奶茶的休闲静谧时光，是幸福且 难求的。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷的用餐环境是非常的优雅和休闲，环境干净卫生，整洁靓丽，对于年轻人来说，简洁大气舒适 感强的店铺装修是非常受欢迎的，相比一些装修华丽，潮流单品的堆砌的奶茶店装修，鹿角巷奶茶店 这种简洁大方的会更加招人喜欢。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">每一个人都能够在这里享受到一个非常舒适放松的奶茶时光。而且很方便，因为鹿角巷都会高度重视 店铺的周边交通和环境，每一家门店所在的位置，都是具有便民，方便寻找，在交通便利的地方。可 以让周边的人随时方便来到店中喝上一杯奶茶。这样方便的店又多了一个可以去的理由。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">加盟热线：400-0388-517</p><p><br/></p>', '2019-11-19', '0', '1590558232', '1590558348', '1');
INSERT INTO `dp_home_news` VALUES ('17', '75', '鹿角巷靠的是实力而不是运气', '台湾新生代知名连锁品牌The Alley鹿角巷，主打生活创意与时尚美学，无论是店内装潢、杯身设计还是品牌风格都相当有范儿，成为潮流时尚男女必去的饮品店之一。', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><a href=\"http://www.lujiaoxiangzongbu.com/\" style=\"margin: 0px; padding: 0px; color: black; text-decoration-line: none;\">鹿角巷</a>，台湾本土奶茶品牌。创立于2014年，五年来，全球门店已近百家。其创始人为台湾知名插画师邱茂庭， 一个品牌的成长，烙印最深的便是创始人，“鹿头”LOGO便是由他手绘。饮品从包装到内里都非常 重视美学，高颜值带来了大量用户，尤其是一群文艺女青年。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷已成立五年之久，全球开店近百家，熟悉各国用户的口味，能根据大量用户的反馈不断更新迭代产品。关 于品牌的含义，邱茂庭在接受采访时曾说：“品牌创立之初，取名为斜角巷，也就是哈利·波特中最繁华的商业街 道，任何新奇有趣的东西都能在那找到。后来担心品牌名字被电影场景局限住了就更名了，以赤鹿作为品牌形象 是因它蕴涵了女性端庄高贵的气质。”</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-size: 0px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><img src=\"/uploads/images/20200527/c97db65442ea45fc4afb3c84f381df14.jpg\" title=\"nx1.jpg\" alt=\"\" width=\"48%\"/> &nbsp; &nbsp;<img src=\"/uploads/images/20200527/a03f6a7d8dbe399cec1ec009257e5388.jpg\" title=\"nx2.jpg\" alt=\"\" width=\"48%\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷最先是在香港火起来的，成为“排队王”后在互联网上迅速扩散。2017年9月，上海第一家店铺开张后，迅速 成为朋友圈的著名”旅游胜地“。一夜之间红炸海岸城，不管暴晒还是下雨，都有粉丝矢志不渝的排队，就为了那一 杯“黑糖鹿丸鲜奶”。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">没有奶粉奶精的加持，用黑糖熬煮很久的珍珠，鲜奶本身木有甜味，整杯的甜都来自杯底的黑糖。吸管插在杯中不同 位置，喝到的感觉会完全不一样，这就是奶茶圈的“泥石流”。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷奶茶味道不甜腻，喝过之后不会刺激你的味觉，更像是一种另你久久不能忘却的温柔，回味便知温情的关怀。 鹿角巷现在成为不少消费者钟意的茶饮，在大街上也能看到各种参差不齐的鹿角巷奶茶店。鹿角巷从来不怕来自同 行竞争，最大的困境，其实是山寨问题。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">大量的山寨店铺也正是说明了鹿角巷具有的极强的品牌影响力。人气和颜值并重，请认准正版鹿角巷!</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">加盟热线：400-0388-517</p><p><br/></p>', '2019-11-18', '0', '1590558418', '1590558528', '1');
INSERT INTO `dp_home_news` VALUES ('18', '72', '鹿角巷奶茶店有亏的吗？它的优势有哪些？', '相信说到目前茶饮市场中的网红奶茶品牌，在大家的心中都会有一个标准的答案，那就是这个公认的奶茶中的泥石流鹿角巷奶茶。', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">有创业者悄悄的问，开<a href=\"http://www.lujiaoxiangzongbu.com/\" style=\"margin: 0px; padding: 0px; color: black; text-decoration-line: none;\">鹿角巷奶茶店</a>有 亏的吗?在这里要很大声的告诉大家，创业加盟这个项目只要按照公司的指导操作就不会亏</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">奶茶是现在很多人都非常爱喝的茶饮品，而鹿角巷奶茶是茶饮行业里一个非常难得的优质奶茶加盟品牌，它在市场 中有着无限的可能性，凭借独特的产品加上别样得口味在市场中脱颖而出，如果选择它进行创业，店铺会盈利的更加轻松。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷产品目前受到众多消费者追捧，在市场中已拥有高知名度。要想开奶茶店那就不要错过了这个项目，鹿角巷的产品丰 富多样，能满足不同创业者的需求。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-size: 0px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><img src=\"/uploads/images/20200527/3659cb979d2373fab425e38f4fc14e41.jpg\" title=\"nx3.jpg\" alt=\"\" width=\"48%\"/> &nbsp; &nbsp;<img src=\"/uploads/images/20200527/7c544ce4836e1c776c50df27504046e7.jpg\" title=\"nx4.jpg\" alt=\"\" width=\"48%\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">了解鹿角巷奶茶项目时，你就会发现它的公司实力非常的雄厚。鹿角巷发源于台湾地区，2019年更是火爆网络。公司的强大 实力支持为您报价护航，安稳开店赚钱。加盟项目可享受到区域保护支持，让创业者获得充分的保护。还有在实际的开店经 营中，能获得总公司提供的活动方案支持。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">选择鹿角巷奶茶项目创业开店，项目能满足不同情况的创业者的需求，将高回报带给大家。来加盟它开店，并根据公司的指 导和规划来，就能安稳的开店盈利。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">加盟热线：400-0388-517</p><p><br/></p>', '2019-11-17', '0', '1590558619', '1590558707', '1');
INSERT INTO `dp_home_news` VALUES ('19', '65', '你必须要知道的鹿角巷奶茶的加盟优势', '鹿角巷奶茶奶茶产品质量上乘，以崭新的奶茶工艺，新鲜黑糖为材料、原茶萃取手艺，打造出了口感纯粹的奶茶。', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><a href=\"http://www.lujiaoxiangzongbu.com/\" style=\"margin: 0px; padding: 0px; color: black; text-decoration-line: none;\">鹿角巷</a>&nbsp;奶茶是目前奶茶市场上很受欢迎的一个奶茶品牌，而且鹿角巷自成立以来一直都是逐 渐稳定上升，从全国十几家加盟店发展至今已拥有一千多家鹿角巷奶茶加盟店，实力 不容小觑，引导了奶茶行业中注重品质健康的新式茶饮潮流，在奶茶市场上占据举足 轻重的地位，拥有众多忠实顾客，选择鹿角巷奶茶加盟投资完全不用担心长期发展问 题，鹿角巷奶茶是一个可以带领加盟商共同致富的一个品牌。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-size: 0px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\"><img src=\"/uploads/images/20200527/1d3cbcd7a65f641a09aaa53845d40f26.jpg\" title=\"nx5.jpg\" alt=\"\" width=\"48%;\"/> &nbsp; &nbsp;<img src=\"/uploads/images/20200527/3225144409b2713d401b04297da30ebd.jpg\" title=\"nx6.jpg\" alt=\"\" width=\"48%;\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷奶茶奶茶产品质量上乘，以崭新的奶茶工艺，新鲜黑糖为材料、原茶萃取手艺， 打造出了口感纯粹的奶茶，保证了本身的口感，鹿角巷奶茶为了让广大的消费者喝得 放心，所有饮品现场制作，无添加任何防腐剂和人工色素，天然健康，满足不同人群的 个性需求。同时根据据市场的需要研发创新，新的产品，提升生产工艺，从而降低成本。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷奶茶店的位置普遍都是人流量很大的步行街、商场和高校附近，这些位置目的消 费人群汇集。再加上如今网络兴旺，外卖的兴起也给鹿角巷奶茶店开拓了一条新的方向 。因而，鹿角巷奶茶加盟店铺有很大一批消费人群。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">鹿角巷加盟品牌对目标客群定位清晰，且所有产品，提供的服务，店面的装修及进行的营 销活动等均围绕其定位进行，每一环都高度匹配的系统化商业模式，相当成功，更重要的 是可以快速复制。深入了解目标客群，运用互联网思维，配以全网推广及OTO组合，进行一 系列与目标客群对话的营销活动，拉近他们与饮品的距离，提升鹿角巷的品牌知名度、美誉 度、忠诚度。正是有鹿角巷奶茶总部的坚持才有今天的鹿角巷。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal;\">加盟热线：400-0388-517</p><p><br/></p>', '2019-11-16', '0', '1590558787', '1590558873', '1');

-- -----------------------------
-- Table structure for `dp_home_page`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_page`;
CREATE TABLE `dp_home_page` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `desc` varchar(255) NOT NULL COMMENT '简介',
  `text` mediumtext NOT NULL COMMENT '文章内容',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='品牌动态';

-- -----------------------------
-- Records of `dp_home_page`
-- -----------------------------
INSERT INTO `dp_home_page` VALUES ('1', '品牌介绍', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">It&#39;s time for Tea</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">秉持着一杯用心看待的好茶·还原记忆中的感动。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">生活的大小设计蜕变到体验生活,尝试将设计与生活作一种体验，从事艺文相关的活动，喜欢手作有温度的各种生活设计,从中的每个地方,得到各种不同的感动。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">在 The Alley里席地而坐,放空想着自己想过的生活,悠闲舒服的为自己来杯午后茶,沉醉在像春日般的梦境,像微甜的蜂蜜,说不上的惬息都会透过 The Alley」的饮品传递在心里It&#39;s time for tea !</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">每个人的心中,都有一杯好茶,在那悠闲的午后,阳光酒落的温度,微风轻拂的快适,情人甜蜜的微笑,口中回甘的韵味·忆起初次暍到好茶的感动,也想把这份美好带给所有的人，秉持这份初衷, T The Alley」就这样诞生了。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">我们坚倍,茶饮,喝的是一份感受,品的是一份幸福,希望将那些藏在你我心底,难以形容却令人神往的写意,透过 The Alley的饮品,再度勾勒出一个美好生活应有的样貌。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-size: 0px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\"><img src=\"/uploads/images/20200526/79d1db047a5048b6902386c54336d8c1.png\" alt=\"\" width=\"48%;\"/><img src=\"/uploads/images/20200526/56a87c17cc72c4a975cea71fcc2a0b27.png\" alt=\"\" width=\"48%;\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">The Alley鹿角巷源自台湾</p><p><br/></p>', '0', '1590480162', '1590482470');
INSERT INTO `dp_home_page` VALUES ('2', '全球门店', '<p><img src=\"/uploads/images/20200526/971473e0c0a203ddcfea2dde409b864f.png\" title=\"md1.png\"/></p><p><img src=\"/uploads/images/20200526/8c47849f95764b3e0635595cb3479a23.png\" title=\"md4.png\"/></p><p><img src=\"/uploads/images/20200526/3ee0bdc2fad9cb7c5025e6266b064036.png\" title=\"md5.png\"/></p><p><img src=\"/uploads/images/20200526/202d9caaf0f3b65a856fd9484f4fe3aa.png\" title=\"md3.png\"/></p><p><img src=\"/uploads/images/20200526/77467b7ade031b984588925e84b216d5.png\" title=\"md6.png\"/></p><p><img src=\"/uploads/images/20200526/7bd0562808d3d6874672b8757a693a13.png\" title=\"md7.png\"/></p><p><img src=\"/uploads/images/20200526/6774cb5a77493a1027892d1bc0d177fc.png\" title=\"md2.png\"/></p><p><img src=\"/uploads/images/20200526/adb3a279dfb20fbc5d5b7bb996f18031.png\" title=\"md9.png\"/></p><p><img src=\"/uploads/images/20200526/92183b86a0109756e128666383558ca3.png\" title=\"md8.png\"/></p><p><br/></p>', '0', '1590482642', '1590482642');
INSERT INTO `dp_home_page` VALUES ('3', '项目优势', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\"><strong style=\"margin: 0px; padding: 0px;\">奶茶市场分析</strong></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">1987年，珍珠奶茶的出现掀起了一番“嗑奶”热潮，奶茶渐渐从店里一个小饮料变成拥有独立店面的主流饮品。大陆地区从最开始的“泡沫红茶”潮流到“奶盖茶”盛行，再到如今火起来的“黑糖奶茶”。30 年间，奶茶在不断迭代升级。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">最近两年，大陆的消费市场开始了翻天覆地的变化，消费升级成了年度热词。不管是价格上，还是奶茶包装设计、口味及品牌形象上，都有了不一样的升级体验。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">在选料和工艺上也发生了变革。开始采用好茶叶，新鲜水果，辅以不同的萃取方式；用新鲜牛奶、进口奶油、天然动物奶油等全方位提升奶茶的口感。奶茶也开始迎来“果茶时代”。很多网红茶都推出了大量的果茶新款。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">店面设计也开始升级。在装修风格上，部分连锁店一改统一的装修风格，为每家店单独设计装修主题，力求为消费者提供舒适体验。大量的网红茶诞生，黑糖奶茶成为新款。鹿角巷等主打“黑糖配奶茶”的奶茶新品牌走进消费者和媒体的视角。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em; text-align: center;\"><img src=\"/uploads/images/20200526/57509a74936a7f81051407af54b120da.png\" title=\"youshi.png\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\"><strong style=\"margin: 0px; padding: 0px;\">鹿角巷奶茶加盟优势</strong></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">时势造英雄。每个时期都有新的匠人加入，从简单的粉末不断改良的纯奶茶，再到口感多层次的“黑糖奶茶”，鹿角巷奶茶的匠人们，都在努力为一代代消费者献上这个时代的最佳味蕾。那么鹿角巷奶茶品牌有哪些优势？</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">好喝。在讲究“体验”的时代，口感变得尤为重要，奶茶也不例外。The Alley鹿角巷奶茶连锁机构把关茶叶及配料的质量、工艺创新及卫生条件，保障产品口感。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">关注健康。消费升级最显著的变化，就是消费者越来越关注健康。新一代奶茶需要改变原有的珍珠、椰果等加工配料，用牛奶和新鲜茶叶，同时增添当季新鲜水果，The Alley鹿角巷采用黑糖等新原料，真正做到口味和品质升级，提供健康新式茶饮。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">持续创新。从“泡沫红茶”到“珍珠奶茶”、“奶盖茶”、“水果茶”，以及最近流行的“黑糖珍珠奶茶”，就是典型的持续创新力的体现。如果跟不上新的流行潮，对连锁奶茶品牌来说就是巨大的挑战。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">品牌力。当然光有好产品也不行，在“酒香也怕巷子深”的年代，品牌知名度和美誉度的助推对一个奶茶产品的成败会变得尤为重要。The Alley鹿角巷通过几年的努力，在不断扩展知名度。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\"><strong style=\"margin: 0px; padding: 0px;\">店铺风格优势</strong></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">①门店氦围复古疤</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">鹿角巷对门面之中的氛围很看重，装修风格清新、简单、舒适,有利于减压，自然能够有不错的人气。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">②汪重品质与口感</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">将产品质量放在第一位，选用鲜牛奶.优质茶叶，自制珍珠等原材料。致力于打造最清新自然口感的饮品</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">③产品王富,潮流时尚</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">总部有专门的研发团队不断创新，倾力为加盟门店提供新品。兼顾各地消费者的口味和偏好，紧跟时崗潮流。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">④造型独特,网红严品</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">在包材的选择上也很用心，使用的是底部圆弧状、杯身从视觉上看相对矮胖的新杯形,俗称“胖胖杯&quot;。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\"><strong style=\"margin: 0px; padding: 0px;\">鹿角巷加盟开店流程</strong></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">1、项目咨询：通过网上留言或电话获取加盟资料；</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">2、总部考察及签约：沟通后到总部参观考察，洽谈合作；</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">3、店面审核；洽谈并确定店铺区域位子；</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">4、店铺签约；</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">5、设计装修；</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">6、店面施工、培训：聘请学员到总部培训专业知识</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">7、工程验收；</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">8、开店筹备；</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">9、试营业：鹿角巷总部派遣运营人员指导开业，跟踪指导运营。</p><p><br/></p>', '0', '1590482816', '1590482893');
INSERT INTO `dp_home_page` VALUES ('4', '加盟扶持', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\"><strong style=\"margin: 0px; padding: 0px;\">鹿角巷加盟费用多少</strong></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">The Alley鹿角巷在2017年成长最快，在这一年间，鹿角巷香港店、上海店等吸引了大批奶茶粉，一下子在国内奶茶品牌发生了质的飞越，已然成为了当下火爆的网红品牌，以其自身优势与特色的黑糖奶茶产品快速的在全国走红，所以不少有创业意向的人也纷纷关注鹿角巷加盟。而鹿角巷的加盟费成了许多加盟商关注的重点。那么成功开一家鹿角巷单店加盟费用是多少呢？</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">The Alley鹿角巷加盟费用是根据店面类型来分，主要有一下几种：</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">1、创业店</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">小店面开店形式，相对来说更简单，适合小本创业者，其投资成本及条件相对较低。The Alley鹿角巷创业店，采用窗口销售形式，无卡座，店面选址比较灵活，对市场要求较低，适合小区及街道，可承接外卖订单等。此类小型店加盟费并不太高，不分地区及区域，具体费用<a href=\"http://lujiaoxiangzongbu.com/Otherpages/lxwm.html\" style=\"margin: 0px; padding: 0px; color: black; text-decoration-line: none;\">(请留言索取加盟资料)</a>。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">2、标准店</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">鹿角巷标准店面，要求相对来说要高一点，但是成本和市场类的要求也比较中等。在The Alley鹿角巷标准店，可设计少量卡座，有一定的空间可供顾客休息、等候、产品较为丰富，对市场要求中等，要求有固定的人流量，适合在较多写字楼的区域。此类加盟店费用需要人工审核，请在线留言给我们。标准店提供的产品较创业店丰富，有针对中高端用户的特定饮品。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em; text-align: center;\"><img src=\"/uploads/images/20200526/0d910705fa0c569214b5126d98748af4.jpg\" title=\"jiameng.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\"><strong style=\"margin: 0px; padding: 0px;\">鹿角巷开店资金准备</strong></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">当你获得鹿角巷加盟店资格以后，必须预留一定数额的周转资金。资金准备得越多，可供你选择的余地也就越大，成功的机会也就越大。通常来说，鹿角巷店所筹备的资金必须能够支付创业第一年内所有的营运开销。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">The Alley鹿角巷奶茶加盟后续需要准备的周转资金如下：</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">1、店铺费用。一般这是开奶茶店的大头，包括了店面的转让费、店租、装修等费用。这类的费用比较杂，同时店租是正常运营要交的费用，因此经营的时候在资金上一定要留有余地，想要维持奶茶店的正常运转，需要有足够的周转资金。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">2、物料费用。除了店面的装修以外，原材料的进货，要根据协议来解决，这需要根据加盟商做好细清单来配备原物料，不止是制作奶茶的原材料，更有各种开奶茶店的必备设备，各类机器，还有吧台器具，店内的各种桌椅等等，这些都是加盟以外的支出。开奶茶店的时候一定要注意到这些。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">3、宣传费用。要让消费者知道鹿角巷的店面信息，就需要投入资金进行宣传，很多时候，除了要把宣传交给品牌以外，很多的宣传还要交给自己来，只有自己最懂得请客，才能有的放矢的进行宣传。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">4、员工费用。作为服务业，奶茶店的支出大头，人工的费用始终会是大头，这一块是鹿角巷奶茶店的经营者，一定要做好成本的预算，才能够让经营持续持续下去。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 24px; text-indent: 32px; font-family: SimSun, &quot;Microsoft YaiHe&quot;; color: rgb(37, 37, 37); white-space: normal; line-height: 1.5em;\">具体的金额应该根据你所选择的项目种类、具体规模、经营地点等情况而定。除了以上四点需要一些周转资金外，其实周转资金并不用太多，因为当店铺运营起来以后，会有源源不断的资金流入，这些可以维持日常开销及原料补给，等到店铺走上正轨以后基本每天都是在收钱了。</p><p><br/></p>', '0', '1590482951', '1590483003');

-- -----------------------------
-- Table structure for `dp_home_product`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_product`;
CREATE TABLE `dp_home_product` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `img` int(11) NOT NULL COMMENT '图片',
  `title` varchar(255) NOT NULL COMMENT '描述',
  `alt` varchar(255) NOT NULL DEFAULT '' COMMENT '替代文本',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `is_tui` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0,1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COMMENT='奶茶产品';

-- -----------------------------
-- Records of `dp_home_product`
-- -----------------------------
INSERT INTO `dp_home_product` VALUES ('1', '14', '阿萨姆拿铁', '阿萨姆拿铁', '0', '1590475707', '1590475707', '1', '1');
INSERT INTO `dp_home_product` VALUES ('2', '15', '黑糖鹿丸鲜奶', '黑糖鹿丸鲜奶', '0', '1590475850', '1590475850', '1', '1');
INSERT INTO `dp_home_product` VALUES ('3', '16', '鹿丸可可鲜奶', '鹿丸可可鲜奶', '0', '1590475871', '1590475871', '1', '1');
INSERT INTO `dp_home_product` VALUES ('4', '17', '小鹿出没', '小鹿出没', '0', '1590475903', '1590475903', '1', '1');
INSERT INTO `dp_home_product` VALUES ('5', '18', '小确幸', '小确幸', '0', '1590475925', '1590475925', '1', '1');
INSERT INTO `dp_home_product` VALUES ('6', '19', '雪莓鹿鹿', '雪莓鹿鹿', '0', '1590475945', '1590475945', '1', '1');
INSERT INTO `dp_home_product` VALUES ('7', '20', '黑糖鹿丸鲜奶', '黑糖鹿丸鲜奶', '0', '1590476025', '1590476025', '1', '0');
INSERT INTO `dp_home_product` VALUES ('8', '21', '小鹿出没', '小鹿出没', '0', '1590476055', '1590476055', '1', '0');
INSERT INTO `dp_home_product` VALUES ('9', '22', '鹿丸可可鲜奶', '鹿丸可可鲜奶', '0', '1590476084', '1590476084', '1', '0');
INSERT INTO `dp_home_product` VALUES ('10', '23', '鹿丸噗哩', '鹿丸噗哩', '0', '1590476101', '1590476101', '1', '0');
INSERT INTO `dp_home_product` VALUES ('11', '24', '雪绒黑糖拿铁', '雪绒黑糖拿铁', '0', '1590476120', '1590476120', '1', '0');
INSERT INTO `dp_home_product` VALUES ('13', '27', '雪绒白桃乌龙', '雪绒白桃乌龙', '0', '1590476597', '1590476597', '1', '0');
INSERT INTO `dp_home_product` VALUES ('14', '28', '恋上海柠威', '恋上海柠威', '0', '1590476622', '1590476622', '1', '0');
INSERT INTO `dp_home_product` VALUES ('15', '29', '热带百香绿', '热带百香绿', '0', '1590476641', '1590476641', '1', '0');
INSERT INTO `dp_home_product` VALUES ('16', '30', '白桃乌龙', '白桃乌龙', '0', '1590476694', '1590476694', '1', '0');
INSERT INTO `dp_home_product` VALUES ('17', '31', '热带百香绿', '热带百香绿', '0', '1590476733', '1590476733', '1', '0');
INSERT INTO `dp_home_product` VALUES ('18', '32', '白桃乌龙', '白桃乌龙', '0', '1590476752', '1590476752', '1', '0');
INSERT INTO `dp_home_product` VALUES ('19', '33', '三巷奶茶', '三巷奶茶', '0', '1590476773', '1590476773', '1', '0');
INSERT INTO `dp_home_product` VALUES ('20', '34', '三巷奶茶', '三巷奶茶', '0', '1590476792', '1590476792', '1', '0');
INSERT INTO `dp_home_product` VALUES ('21', '35', '盆栽奶茶', '盆栽奶茶', '0', '1590476811', '1590476811', '1', '0');
INSERT INTO `dp_home_product` VALUES ('22', '36', '盆栽奶茶', '盆栽奶茶', '0', '1590476823', '1590476823', '1', '0');
INSERT INTO `dp_home_product` VALUES ('23', '37', '皇家九号奶茶', '皇家九号奶茶', '0', '1590476843', '1590476843', '1', '0');
INSERT INTO `dp_home_product` VALUES ('24', '38', '皇家九号奶茶', '皇家九号奶茶', '0', '1590476856', '1590476856', '1', '0');
INSERT INTO `dp_home_product` VALUES ('25', '39', '奶香铁观音', '奶香铁观音', '0', '1590476877', '1590476877', '1', '0');
INSERT INTO `dp_home_product` VALUES ('26', '40', '皇家九号拿铁', '皇家九号拿铁', '0', '1590476903', '1590476903', '1', '0');
INSERT INTO `dp_home_product` VALUES ('27', '41', '皇家九号拿铁', '皇家九号拿铁', '0', '1590476924', '1590476924', '1', '0');
INSERT INTO `dp_home_product` VALUES ('28', '42', '可可拿铁', '可可拿铁', '0', '1590476941', '1590476941', '1', '0');
INSERT INTO `dp_home_product` VALUES ('29', '43', '皇家九号红茶', '皇家九号红茶', '0', '1590476960', '1590476960', '1', '0');
INSERT INTO `dp_home_product` VALUES ('30', '44', '小山绿茶', '小山绿茶', '0', '1590476980', '1590476980', '1', '0');
INSERT INTO `dp_home_product` VALUES ('31', '45', '晨露', '晨露', '0', '1590477104', '1590477104', '1', '0');
INSERT INTO `dp_home_product` VALUES ('32', '46', '晨曦', '晨曦', '0', '1590477125', '1590477125', '1', '0');
INSERT INTO `dp_home_product` VALUES ('33', '47', '北极光', '北极光', '0', '1590477141', '1590477141', '1', '0');
INSERT INTO `dp_home_product` VALUES ('34', '48', '北极光', '北极光', '0', '1590477466', '1590477466', '1', '0');
INSERT INTO `dp_home_product` VALUES ('35', '49', '卡波查拿铁', '卡波查拿铁', '0', '1590477497', '1590477497', '1', '0');
INSERT INTO `dp_home_product` VALUES ('36', '50', '卡波查冰沙', '卡波查冰沙', '0', '1590477518', '1590477518', '1', '0');
INSERT INTO `dp_home_product` VALUES ('37', '51', '卡波查冰沙', '卡波查冰沙', '0', '1590477539', '1590477539', '1', '0');
